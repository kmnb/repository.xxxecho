import unittest

class YetAnotherSampleTest(unittest.TestCase):
    
    def setUp(self):
        return

    def tearDown(self):
        return

    def test_abc(self):
        pass


if __name__ == '__main__':
    unittest.main()
