"""
    Copyright (C) 2016 ECHO Coder

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
#Imports
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import urllib2,urllib
import time
import requests
import re

#Default veriables
AddonTitle     = "XNXX.com"
addon_id       = 'plugin.video.xnxxcom'
ADDON          = xbmcaddon.Addon(id=addon_id)
fanart         = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon           = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
next_icon      = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/next.png'))
search_icon    = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'resources/art/search.png'))

def MAIN_MENU():
	
	featured_url = 'http://www.xnxx.com'
	addDir("[COLOR yellow][B]Search[/B][/COLOR]","url",2,search_icon,fanart,'')
	addDir("[COLOR blue][B][I]FEATURED[/I][/B][/COLOR]",featured_url,1,icon,fanart,'')

	result = requests.get('http://www.xnxx.com')
	
	match = re.compile('<div id="side-categories" class="mobile-hide">(.+?)<div id="content-ad-side" class="mobile-hide">',re.DOTALL).findall(result.content)
	string = str(match)
	match2 = re.compile('{(.+?)}',re.DOTALL).findall(string)

	for item in match2:
		title=re.compile('label":"(.+?)"').findall(item)[0]
		url=re.compile('"url":".+?/(.+?)"').findall(item)[0]
		url3 = url
		url4 = url3.replace('\\','')
		url = "http://www.xnxx.com/" + url4
		name = "[COLOR blue][B]" + title + "[/B][/COLOR]"
		addDir(name,url,1,icon,fanart,'')

def GET_CONTENT(url):

	checker = url
	result = requests.get(url)
	match = re.compile('<div id="video(.+?)</p></div>',re.DOTALL).findall(result.content)
	for item in match:
		title=re.compile('title=(.+?)">').findall(item)[0]
		url=re.compile('<a href="(.+?)"').findall(item)[0]
		iconimage=re.compile('<img src="(.+?)"').findall(item)[0]
		name = "[COLOR blue]" + title + "[/COLOR]"
		name = name.replace('"','')
		addItem(name,url,3,iconimage,iconimage,'')

	try:
		np=re.compile('<a href="([^"]*)" class="no-page">Next</a></li></ul></div>').findall(result.content)[0]
		np = 'http://www.xnxx.com'+np
		addDir('[COLOR yellow]Next Page >>[/COLOR]',np,1,next_icon,fanart,'')       
	except:pass

	if not "http://www.xnxx.com/home/10" in checker:
		if "/home/" in checker:
			a,b,c,d,e = checker.split('/')
			new = int(float(e)) + 1
			url = "http://www.xnxx.com/home/" + str(new)
			addDir('[COLOR yellow]Next Page >>[/COLOR]',url,1,next_icon,fanart,'')   
		elif checker == "http://www.xnxx.com":
			url = "http://www.xnxx.com/home/1"
			addDir('[COLOR yellow]Next Page >>[/COLOR]',url,1,next_icon,fanart,'')
	xbmc.executebuiltin('Container.SetViewMode(500)')

def SEARCH():

    string =''
    keyboard = xbmc.Keyboard(string, 'Enter Search Term')
    keyboard.doModal()
    if keyboard.isConfirmed():
        string = keyboard.getText().replace(' ','').capitalize()
        if len(string)>1:
            url = "http://www.xnxx.com/?k=" + string
            GET_CONTENT(url)
        else: quit()

def PLAY_URL(name,url,iconimage):
	
	url = "http://www.xnxx.com/" + url
	result = requests.get(url)
	match = re.compile('<head>(.+?)</html>',re.DOTALL).findall(result.content)
	string = str(match).replace('\\','').replace('(','').replace(')','')
	url = re.compile("setVideoUrlHigh'(.+?)'").findall(string)[0]
	liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	xbmc.Player ().play(url, liz, False)


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                               
        return param

def addItem(name,url,mode,iconimage,fanart,description=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

def addDir(name,url,mode,iconimage,fanart,description=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

params=get_params(); url=None; name=None; mode=None; site=None; description=None
try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: mode=int(params["mode"])
except: pass
try: description=urllib.quote_plus(params["description"])
except: pass

  
if mode==None or url==None or len(url)<1: MAIN_MENU()
elif mode==1: GET_CONTENT(url)
elif mode==2: SEARCH()
elif mode==3: PLAY_URL(name,url,iconimage)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
