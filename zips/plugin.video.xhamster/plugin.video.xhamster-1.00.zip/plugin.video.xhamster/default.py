#Imports
import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os , base64 , sys , xbmcvfs
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
if 46 - 46: ooOoO0o * I11i - OoooooooOO
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
if 94 - 94: i1IIi % Oo0Ooo
if 68 - 68: Ii1I / O0
if 46 - 46: O0 * II111iiii / IiII * Oo0Ooo * iII111i . I11i
if 62 - 62: i11iIiiIii - II111iiii % I1Ii111 - iIii1I11I1II1 . I1ii11iIi11i . II111iiii
if 61 - 61: oO0o / OoOoOO00 / iII111i * OoO0O00 . II111iiii
if 1 - 1: II111iiii - I1ii11iIi11i % i11iIiiIii + IiII . I1Ii111
if 55 - 55: iIii1I11I1II1 - I1IiiI . Ii1I * IiII * i1IIi / iIii1I11I1II1
import urllib2 , urllib
import time
import base64
import re
if 79 - 79: oO0o + I1Ii111 . ooOoO0o * IiII % I11i . I1IiiI
if 94 - 94: iII111i * Ii1I / IiII . i1IIi * iII111i
iiiii11iII1 = "[COLOR red]Xhamster[/COLOR]"
O0o = 'plugin.video.xhamster'
oO0 = xbmcgui . Dialog ( )
IIIi1i1I = xbmcaddon . Addon ( id = O0o )
OOoOoo00oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + O0o , 'fanart.jpg' ) )
iiI11 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + O0o , 'icon.png' ) )
if 91 - 91: o0oOOo0O0Ooo / II111iiii . I1ii11iIi11i + OOooOOo
iI11 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + O0o , 'controls.txt' ) )
iII111ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + O0o , 'disclaimer.txt' ) )
i1iIIi1 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + O0o , 'agreed.txt' ) )
ii11iIi1I = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + O0o ) )
if 6 - 6: OoOoOO00 * iII111i
O00O0O0O0 = 'https://xhamster.com/last50.php'
ooO0O = 'https://xhamster.com/rankings/weekly-top-videos.html'
oo = 'https://xhamster.com/rankings/weekly-top-commented.html'
iii11iII = 'https://xhamster.com/rankings/weekly-top-viewed.html'
if 42 - 42: I1Ii111 + I1ii11iIi11i
def OOoO000O0OO ( ) :
 if 23 - 23: i11iIiiIii + I1IiiI
 if not os . path . exists ( i1iIIi1 ) :
  oOo = open ( iII111ii , mode = 'r' ) ; oOoOoO = oOo . read ( ) ; oOo . close ( )
  ii1I ( "%s" % oOoOoO )
  OooO0 = xbmcgui . Dialog ( ) . yesno ( iiiii11iII1 , '[COLOR white]Do you agree to the terms and conditions of this addon?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[COLOR red]NO[/COLOR]' )
  if OooO0 == 1 :
   if not os . path . exists ( ii11iIi1I ) :
    os . makedirs ( ii11iIi1I )
   open ( i1iIIi1 , 'w' )
  else :
   sys . exit ( 0 )
   if 35 - 35: OOooOOo % I1Ii111 % i11iIiiIii / OoooooooOO
 if not os . path . exists ( ii11iIi1I ) :
  OooO0 = xbmcgui . Dialog ( ) . yesno ( iiiii11iII1 , "[COLOR white]We can see that this is your first time using the addon. Would you like to enable the parental controls now?[/COLOR]" , "" , yeslabel = '[COLOR red]NO[/COLOR]' , nolabel = '[COLOR lime]YES[/COLOR]' )
  if OooO0 == 0 :
   Ii11iI1i ( )
  else :
   os . makedirs ( ii11iIi1I )
   if 82 - 82: i11iIiiIii . OOooOOo / Oo0Ooo * O0 % oO0o % iIii1I11I1II1
 elif os . path . exists ( iI11 ) :
  Oo00OOOOO = O0O ( heading = "Please Enter Your Password" )
  if ( not Oo00OOOOO ) :
   oO0 . ok ( iiiii11iII1 , "Sorry, no password was entered." )
   sys . exit ( 0 )
  O00o0OO = Oo00OOOOO
  if 44 - 44: IiII / O0 % i1IIi * oO0o + Oo0Ooo
  Ii1IOo0o0 = open ( iI11 , "r" )
  III1ii1iII = re . compile ( r'<password>(.+?)</password>' )
  for oo0oooooO0 in Ii1IOo0o0 :
   file = III1ii1iII . findall ( oo0oooooO0 )
   for i11Iiii in file :
    iI = base64 . b64decode ( i11Iiii )
    if not iI == O00o0OO :
     if not i11Iiii == O00o0OO :
      oO0 . ok ( iiiii11iII1 , "Sorry, the password you entered was incorrect." )
      sys . exit ( 0 )
      if 28 - 28: OOooOOo - IiII . IiII + OoOoOO00 - OoooooooOO + O0
 oOoOooOo0o0 ( "[COLOR ghostwhite]SEARCH[/COLOR]" , "url" , 2 , iiI11 , OOoOoo00oo , '' )
 oOoOooOo0o0 ( "[COLOR white][I]50 NEWEST VIDEOS[/I][/COLOR]" , O00O0O0O0 , 1 , iiI11 , OOoOoo00oo , '' )
 oOoOooOo0o0 ( "[COLOR white][I]TOP RATED[/I][/COLOR]" , ooO0O , 1 , iiI11 , OOoOoo00oo , '' )
 oOoOooOo0o0 ( "[COLOR white][I]MOST VIEWED[/I][/COLOR]" , iii11iII , 1 , iiI11 , OOoOoo00oo , '' )
 oOoOooOo0o0 ( "[COLOR white][I]MOST COMMENTED[/I][/COLOR]" , oo , 1 , iiI11 , OOoOoo00oo , '' )
 if 61 - 61: o0oOOo0O0Ooo / OoO0O00 + ooOoO0o * oO0o / oO0o
 OoOo = iIo00O ( 'https://www.xhamster.com' )
 if 69 - 69: oO0o % I1Ii111 - o0oOOo0O0Ooo + I1Ii111 - O0 % OoooooooOO
 Iii111II = re . compile ( '<div class="head" data-block="channels-straight">(.+?)<a href="https://xhamster.com/channels.php" class="bottom">' , re . DOTALL ) . findall ( OoOo )
 iiii11I = str ( Iii111II )
 Ooo0OO0oOO = re . compile ( '<a(.+?)/a>' , re . DOTALL ) . findall ( iiii11I )
 ii11i1 = 0
 IIIii1II1II = 0
 for i1I1iI in Ooo0OO0oOO :
  try :
   oo0OooOOo0 = re . compile ( 'href=".+?">(.+?)<' ) . findall ( i1I1iI ) [ 0 ]
   o0O = re . compile ( 'href="(.+?)">.+?<' ) . findall ( i1I1iI ) [ 0 ]
   O00oO = "[COLOR snowwhite]" + oo0OooOOo0 + "[/COLOR]"
   O00oO = I11i1I1I ( O00oO )
   if not "<" in O00oO :
    oOoOooOo0o0 ( O00oO , o0O , 1 , iiI11 , OOoOoo00oo , '' )
  except : pass
  if 83 - 83: I1ii11iIi11i / ooOoO0o
 iIIIIii1 ( "[COLOR white]Twitter Support: @EchoCoder[/COLOR]" , "url" , 999 , iiI11 , OOoOoo00oo , '' )
 if not os . path . exists ( iI11 ) :
  oOoOooOo0o0 ( "[COLOR orangered]PARENTAL CONTROLS - [COLOR red]OFF[/COLOR][/COLOR]" , "url" , 11 , iiI11 , OOoOoo00oo , '' )
 else :
  oOoOooOo0o0 ( "[COLOR orangered]PARENTAL CONTROLS - [COLOR lime]ON[/COLOR][/COLOR]" , "url" , 11 , iiI11 , OOoOoo00oo , '' )
  if 58 - 58: i11iIiiIii % I11i
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 71 - 71: OOooOOo + ooOoO0o % i11iIiiIii + I1ii11iIi11i - IiII
def oO0OOoO0 ( url ) :
 if 34 - 34: IiII - IiII * I1IiiI + Ii1I % IiII
 i111IiI1I = url
 OoOo = iIo00O ( url )
 if '<div id="searchLoader">' in OoOo :
  Iii111II = re . compile ( '<div id="searchLoader">(.+?)iconPagerNextHover' , re . DOTALL ) . findall ( OoOo )
 elif 'last50.php' in url :
  Iii111II = re . compile ( 'href="/last50.php">(.+?)<div id="footer">' , re . DOTALL ) . findall ( OoOo )
 elif '<div class="video new-date">' in OoOo :
  Iii111II = re . compile ( '<div class="video new-date">(.+?)<div class="category-related-container">' , re . DOTALL ) . findall ( OoOo )
 else :
  Iii111II = re . compile ( "id='vListTop'>(.+?)<div class='pager'>" , re . DOTALL ) . findall ( OoOo )
  if 70 - 70: Ii1I . Oo0Ooo / o0oOOo0O0Ooo . Ii1I - O0 / IiII
 iiii11I = str ( Iii111II )
 Ooo0OO0oOO = re . compile ( '<a(.+?)<div class="video">' , re . DOTALL ) . findall ( iiii11I )
 if 62 - 62: iIii1I11I1II1 * OoOoOO00
 for i1I1iI in Ooo0OO0oOO :
  oo0OooOOo0 = re . compile ( 'alt="(.+?)"' ) . findall ( i1I1iI ) [ 0 ]
  url = re . compile ( 'href="(.+?)"' ) . findall ( i1I1iI ) [ 0 ]
  i1 = re . compile ( '<div class="fr">(.+?)</div>' ) . findall ( i1I1iI ) [ 0 ]
  OOO = re . compile ( '<b>(.+?)</b>' ) . findall ( i1I1iI ) [ 0 ]
  try :
   Oo0oOOo = re . compile ( '<div class="views-value">(.+?)</div>' ) . findall ( i1I1iI ) [ 0 ]
  except : Oo0oOOo = "Unknown"
  try :
   Oo0OoO00oOO0o = re . compile ( '<img src=(.+?) class' ) . findall ( i1I1iI ) [ 0 ]
   OOO00O = str ( Oo0OoO00oOO0o )
   Oo0OoO00oOO0o = OOO00O . replace ( "\'" , '' ) . replace ( "\'" , '' ) . replace ( "\\" , '' )
  except : Oo0OoO00oOO0o = iiI11
  OOoOO0oo0ooO = "[COLOR red]" + i1 + "[/COLOR]"
  O00oO = "[COLOR white] - " + oo0OooOOo0 + "[/COLOR]"
  O0o0O00Oo0o0 = "[COLOR grey] | [I]Length: " + OOO + "[/I][/COLOR]"
  O00O0oOO00O00 = "[COLOR grey] | [I]Views: " + Oo0oOOo + "[/I][/COLOR]"
  url = url + "&Referer=" + i111IiI1I
  O00oO = I11i1I1I ( O00oO )
  iIIIIii1 ( OOoOO0oo0ooO + O00oO + O0o0O00Oo0o0 + O00O0oOO00O00 , url , 3 , Oo0OoO00oOO0o , OOoOoo00oo , '' )
 try :
  if "class='last' overicon='iconPagerNextHover'>" in OoOo :
   i1Oo00 = re . compile ( "<a href='([^']*)' class='last' overicon='iconPagerNextHover'>" ) . findall ( OoOo ) [ 0 ]
  else :
   i1Oo00 = re . compile ( '<link rel="next" href="(.+?)"' ) . findall ( OoOo ) [ 0 ]
  i1Oo00 = i1Oo00 . replace ( '&amp;' , '&' )
  oOoOooOo0o0 ( '[COLOR white]Next Page >>[/COLOR]' , i1Oo00 , 1 , iiI11 , OOoOoo00oo , '' )
 except : pass
 if 31 - 31: I1Ii111 . OoOoOO00 / O0
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 89 - 89: OoOoOO00
def OO0oOoOO0oOO0 ( ) :
 if 86 - 86: OOooOOo
 iiii11I = ''
 OOoo0O = xbmc . Keyboard ( iiii11I , 'Enter Search Term' )
 OOoo0O . doModal ( )
 if OOoo0O . isConfirmed ( ) :
  iiii11I = OOoo0O . getText ( ) . replace ( ' ' , '+' )
  if len ( iiii11I ) > 1 :
   o0O = "https://xhamster.com/search.php?from=&new=&q=" + iiii11I . lower ( ) + "&qcat=video"
   oO0OOoO0 ( o0O )
  else : quit ( )
  if 67 - 67: i11iIiiIii - i1IIi % I1ii11iIi11i . O0
def o0oo ( name , url , iconimage ) :
 if 91 - 91: IiII
 iiIii = url . split ( "&Referer" ) [ 0 ]
 ooo0O = oOoO0o00OO0 ( )
 OoOo = iIo00O ( url )
 url = re . compile ( "file: '(.+?)'" , re . DOTALL ) . findall ( OoOo ) [ 0 ]
 url = url . replace ( "['" , '' ) . replace ( "']" , '' ) . replace ( '%3A%2F%2F' , '://' ) . replace ( '%2F' , '/' )
 ooo0O . close ( )
 if 7 - 7: OOooOOo + I1Ii111 + O0
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + iiIii
 Ii = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , Ii , False )
 if 64 - 64: ooOoO0o / OoOoOO00 - O0 - I11i
def O0oOoOOOoOO ( ) :
 if 38 - 38: I1Ii111
 Ii1 = 0
 if not os . path . exists ( iI11 ) :
  Ii1 = 1
  iIIIIii1 ( "[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR red]OFF[/COLOR]" , "url" , 999 , iiI11 , OOoOoo00oo , '' )
  iIIIIii1 ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 12 , iiI11 , OOoOoo00oo , '' )
 else :
  Ii1IOo0o0 = open ( iI11 , "r" )
  III1ii1iII = re . compile ( r'<password>(.+?)</password>' )
  for oo0oooooO0 in Ii1IOo0o0 :
   file = III1ii1iII . findall ( oo0oooooO0 )
   for i11Iiii in file :
    iI = base64 . b64decode ( i11Iiii )
    Ii1 = 1
    iIIIIii1 ( "[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR lime]ON[/COLOR]" , "url" , 999 , iiI11 , OOoOoo00oo , '' )
    iIIIIii1 ( "[COLOR white]Current Password - [/COLOR][COLOR orangered]" + str ( iI ) + "[/COLOR]" , "url" , 999 , iiI11 , OOoOoo00oo , '' )
    iIIIIii1 ( "[COLOR lime]Change Password[/COLOR]" , "url" , 12 , iiI11 , OOoOoo00oo , '' )
    iIIIIii1 ( "[COLOR red]Disable Password[/COLOR]" , "url" , 13 , iiI11 , OOoOoo00oo , '' )
    if 82 - 82: I1ii11iIi11i - iIii1I11I1II1 / OOooOOo + Ii1I
 if Ii1 == 0 :
  iIIIIii1 ( "[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR red]OFF[/COLOR]" , "url" , 999 , iiI11 , OOoOoo00oo , '' )
  iIIIIii1 ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 12 , iiI11 , OOoOoo00oo , '' )
  if 87 - 87: oO0o * I1ii11iIi11i + OOooOOo / iIii1I11I1II1 / iII111i
def Ii11iI1i ( ) :
 if 37 - 37: iII111i - ooOoO0o * oO0o % i11iIiiIii - I1Ii111
 Oo00OOOOO = O0O ( heading = "Please Set Password" )
 if ( not Oo00OOOOO ) :
  oO0 . ok ( iiiii11iII1 , "Sorry, no password was entered." )
  sys . exit ( 0 )
 O00o0OO = Oo00OOOOO
 if 83 - 83: I11i / I1IiiI
 Oo00OOOOO = O0O ( heading = "Please Confirm Your Password" )
 if ( not Oo00OOOOO ) :
  oO0 . ok ( iiiii11iII1 , "Sorry, no password was entered." )
  sys . exit ( 0 )
 iIIiIi1iIII1 = Oo00OOOOO
 if 78 - 78: O0 . oO0o . II111iiii % OOooOOo
 if not os . path . exists ( iI11 ) :
  if not os . path . exists ( ii11iIi1I ) :
   os . makedirs ( ii11iIi1I )
  open ( iI11 , 'w' )
  if 49 - 49: Ii1I / OoO0O00 . II111iiii
  if O00o0OO == iIIiIi1iIII1 :
   ooOOoooooo = base64 . b64encode ( O00o0OO )
   oOo = open ( iI11 , 'w' )
   oOo . write ( '<password>' + str ( ooOOoooooo ) + '</password>' )
   oOo . close ( )
   oO0 . ok ( iiiii11iII1 , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   oO0 . ok ( iiiii11iII1 , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
 else :
  os . remove ( iI11 )
  if 1 - 1: Oo0Ooo / o0oOOo0O0Ooo % iII111i * IiII . i11iIiiIii
  if O00o0OO == iIIiIi1iIII1 :
   ooOOoooooo = base64 . b64encode ( O00o0OO )
   oOo = open ( iI11 , 'w' )
   oOo . write ( '<password>' + str ( ooOOoooooo ) + '</password>' )
   oOo . close ( )
   oO0 . ok ( iiiii11iII1 , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   oO0 . ok ( iiiii11iII1 , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
   if 2 - 2: I1ii11iIi11i * I11i - iIii1I11I1II1 + I1IiiI . oO0o % iII111i
def ooOOOoOooOoO ( ) :
 if 91 - 91: iII111i % i1IIi % iIii1I11I1II1
 try :
  os . remove ( iI11 )
  oO0 . ok ( iiiii11iII1 , 'Parental controls have been disabled.' )
  xbmc . executebuiltin ( "Container.Refresh" )
 except :
  oO0 . ok ( iiiii11iII1 , 'There was an error disabling the parental controls.' )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 20 - 20: OOooOOo % Ii1I / Ii1I + Ii1I
def oOoO0o00OO0 ( ) :
 if 45 - 45: oO0o - IiII - OoooooooOO - OoO0O00 . II111iiii / O0
 import random
 oo0o00O = random . randrange ( 10 )
 if 51 - 51: Ii1I - OoO0O00 * iII111i
 ooo0O = xbmcgui . DialogProgress ( )
 if 66 - 66: OoooooooOO + O0
 if oo0o00O == 1 :
  ooo0O . create ( iiiii11iII1 , "[COLOR white]Please wait.[/COLOR]" , '[COLOR red]We are getting the moisturiser.[/COLOR]' , '[COLOR azure]Do you have the wipes ready?[/COLOR]' )
 elif oo0o00O == 2 :
  ooo0O . create ( iiiii11iII1 , "[COLOR white]Please wait.[/COLOR]" , '[COLOR red]I am just taking off my pants.[/COLOR]' , '[COLOR azure]Darn belt![/COLOR]' )
 elif oo0o00O == 3 :
  ooo0O . create ( iiiii11iII1 , "[COLOR white]Please wait.[/COLOR]" , '[COLOR red]Are the curtains closed?[/COLOR]' , '[COLOR azure]Oh baby its cold outside![/COLOR]' )
 elif oo0o00O == 4 :
  ooo0O . create ( iiiii11iII1 , "[COLOR white]Please wait.[/COLOR]" , '[COLOR red]This is my fifth time today.[/COLOR]' , '[COLOR azure]How about you?[/COLOR]' )
 elif oo0o00O == 5 :
  ooo0O . create ( iiiii11iII1 , "[COLOR white]Please wait.[/COLOR]" , '[COLOR red]Please no buffer, please no buffer![/COLOR]' )
 elif oo0o00O == 6 :
  ooo0O . create ( iiiii11iII1 , "[COLOR white]Please wait.[/COLOR]" , '[COLOR red]I think I am going blind :-/[/COLOR]' , '[COLOR azure]Oh no, just something in my eye.[/COLOR]' )
 elif oo0o00O == 7 :
  ooo0O . create ( iiiii11iII1 , "[COLOR white]Please wait.[/COLOR]" , '[COLOR red]Did I turn the oven off?[/COLOR]' , '[COLOR azure]It can wait![/COLOR]' )
 elif oo0o00O == 8 :
  ooo0O . create ( iiiii11iII1 , "[COLOR white]Please wait.[/COLOR]" , '[COLOR red]Your video is coming. Are you?[/COLOR]' , '[COLOR azure]Do you get it?[/COLOR]' )
 elif oo0o00O == 9 :
  ooo0O . create ( iiiii11iII1 , "[COLOR white]Please wait.[/COLOR]" , '[COLOR red]Kodi does not save your browsing history :-D[/COLOR]' , '[COLOR azure]Thats lucky isnt it :-)[/COLOR]' )
 else :
  ooo0O . create ( iiiii11iII1 , "[COLOR white]Please wait.[/COLOR]" , '[COLOR red]There are more XXX addons by ECHO.[/COLOR]' , '[COLOR azure]Just so you know.[/COLOR]' )
  if 11 - 11: I11i + OoooooooOO - OoO0O00 / o0oOOo0O0Ooo + Oo0Ooo . II111iiii
 return ooo0O
 if 41 - 41: Ii1I - O0 - O0
def I11i1I1I ( text ) :
 if 68 - 68: OOooOOo % I1Ii111
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , '\n' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 if 88 - 88: iIii1I11I1II1 - ooOoO0o + OOooOOo
 return text
 if 40 - 40: I1IiiI * Ii1I + OOooOOo % iII111i
def ii1I ( announce ) :
 class OOOOOoo0 ( ) :
  WINDOW = 10147
  CONTROL_LABEL = 1
  CONTROL_TEXTBOX = 5
  def __init__ ( self , * args , ** kwargs ) :
   xbmc . executebuiltin ( "ActivateWindow(%d)" % ( self . WINDOW , ) )
   self . win = xbmcgui . Window ( self . WINDOW )
   xbmc . sleep ( 500 )
   self . setControls ( )
  def setControls ( self ) :
   self . win . getControl ( self . CONTROL_LABEL ) . setLabel ( 'XNXX.com - Story' )
   try : oOo = open ( announce ) ; ii1 = oOo . read ( )
   except : ii1 = announce
   self . win . getControl ( self . CONTROL_TEXTBOX ) . setText ( str ( ii1 ) )
   return
 OOOOOoo0 ( )
 while xbmc . getCondVisibility ( 'Window.IsVisible(10147)' ) :
  time . sleep ( .5 )
  if 11 - 11: IiII * I1IiiI . iIii1I11I1II1 % OoooooooOO + iII111i
def O0O ( default = "" , heading = "" , hidden = False ) :
 OOoo0O = xbmc . Keyboard ( default , heading , hidden )
 if 78 - 78: OoO0O00 . OOooOOo + OoO0O00 / I11i / OoO0O00
 OOoo0O . doModal ( )
 if ( OOoo0O . isConfirmed ( ) ) :
  return unicode ( OOoo0O . getText ( ) , "utf-8" )
 return default
 if 54 - 54: OoOoOO00 % iII111i
def iIo00O ( url ) :
 IIiII111iiI1I = urllib2 . Request ( url )
 IIiII111iiI1I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36' )
 Ii1i1iI1iIIi = urllib2 . urlopen ( IIiII111iiI1I )
 I1Ii = Ii1i1iI1iIIi . read ( )
 Ii1i1iI1iIIi . close ( )
 return I1Ii
 if 94 - 94: Ii1I - II111iiii . OOooOOo % I11i . i11iIiiIii + O0
def iIIIIii1 ( name , url , mode , iconimage , fanart , description = '' ) :
 if 26 - 26: I11i - iIii1I11I1II1 - I1IiiI / OoO0O00 . OoOoOO00 % iIii1I11I1II1
 Ii = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 Ii . setProperty ( 'fanart_image' , fanart )
 OO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 iIiIIi1 = True
 iIiIIi1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO , listitem = Ii , isFolder = False )
 return iIiIIi1
 if 7 - 7: ooOoO0o - Oo0Ooo - oO0o + ooOoO0o
def oOoOooOo0o0 ( name , url , mode , iconimage , fanart , description = '' ) :
 OO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 iIiIIi1 = True
 Ii = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 Ii . setProperty ( 'fanart_image' , fanart )
 iIiIIi1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO , listitem = Ii , isFolder = True )
 return iIiIIi1
 if 26 - 26: Ii1I
def I11iiI1i1 ( ) :
 I1i1Iiiii = [ ]
 OOo0oO00ooO00 = sys . argv [ 2 ]
 if len ( OOo0oO00ooO00 ) >= 2 :
  oOO0O00oO0Ooo = sys . argv [ 2 ]
  oO0Oo0O0o = oOO0O00oO0Ooo . replace ( '?' , '' )
  if ( oOO0O00oO0Ooo [ len ( oOO0O00oO0Ooo ) - 1 ] == '/' ) :
   oOO0O00oO0Ooo = oOO0O00oO0Ooo [ 0 : len ( oOO0O00oO0Ooo ) - 2 ]
  OOI1iI1ii1II = oO0Oo0O0o . split ( '&' )
  I1i1Iiiii = { }
  for O0O0OOOOoo in range ( len ( OOI1iI1ii1II ) ) :
   oOooO0 = { }
   oOooO0 = OOI1iI1ii1II [ O0O0OOOOoo ] . split ( '=' )
   if ( len ( oOooO0 ) ) == 2 :
    I1i1Iiiii [ oOooO0 [ 0 ] ] = oOooO0 [ 1 ]
    if 29 - 29: iIii1I11I1II1 + OoOoOO00 * OoO0O00 * OOooOOo . I1IiiI * I1IiiI
 return I1i1Iiiii
 if 7 - 7: IiII * I1Ii111 % Ii1I - o0oOOo0O0Ooo
oOO0O00oO0Ooo = I11iiI1i1 ( ) ; o0O = None ; O00oO = None ; i1i = None ; oOOoo00O00o = None ; Oo0OoO00oOO0o = None
try : oOOoo00O00o = urllib . unquote_plus ( oOO0O00oO0Ooo [ "site" ] )
except : pass
try : o0O = urllib . unquote_plus ( oOO0O00oO0Ooo [ "url" ] )
except : pass
try : O00oO = urllib . unquote_plus ( oOO0O00oO0Ooo [ "name" ] )
except : pass
try : i1i = int ( oOO0O00oO0Ooo [ "mode" ] )
except : pass
try : Oo0OoO00oOO0o = urllib . unquote_plus ( oOO0O00oO0Ooo [ "iconimage" ] )
except : pass
try : OOoOoo00oo = urllib . unquote_plus ( oOO0O00oO0Ooo [ "fanart" ] )
except : pass
if 98 - 98: OOooOOo + IiII + oO0o % OoooooooOO
if i1i == None or o0O == None or len ( o0O ) < 1 : OOoO000O0OO ( )
elif i1i == 1 : oO0OOoO0 ( o0O )
elif i1i == 2 : OO0oOoOO0oOO0 ( )
elif i1i == 3 : o0oo ( O00oO , o0O , Oo0OoO00oOO0o )
elif i1i == 11 : O0oOoOOOoOO ( )
elif i1i == 12 : Ii11iI1i ( )
elif i1i == 13 : ooOOOoOooOoO ( )
if 97 - 97: O0 * OoooooooOO . OoooooooOO
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )