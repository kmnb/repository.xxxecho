import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , shutil
import base64 , time , datetime
from resources . lib . modules import plugintools
from resources . lib . modules import common
from resources . lib . scrapers import chaturbate
from resources . lib . scrapers import xnxx
from resources . lib . scrapers import youporn
from resources . lib . scrapers import porncom
from resources . lib . scrapers import pornhd
from resources . lib . scrapers import redtube
from resources . lib . scrapers import xhamster
from resources . lib . scrapers import pornfun
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.xxx-o-dus'
Oo0Ooo = '[COLOR red]XXX-O-DUS[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/xhamster/icon.png' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/xhamster/fanart.jpg' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/chaturbate/icon.png' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/chaturbate/fanart.jpg' ) )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/xnxx/icon.png' ) )
I11i11Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/xnxx/fanart.jpg' ) )
oO00oOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/redtube/icon.png' ) )
OOOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/redtube/fanart.jpg' ) )
Oooo000o = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/pornhd/icon.png' ) )
IiIi11iIIi1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/pornhd/fanart.jpg' ) )
Oo0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/porncom/icon.png' ) )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/porncom/fanart.jpg' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/youporn/icon.png' ) )
Oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/youporn/fanart.jpg' ) )
o0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/pornfun/icon.png' ) )
IiiIII111iI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/pornfun/fanart.jpg' ) )
if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . I1i1iI1i - II
OoI1Ii11I1Ii1i = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
Ooo = xbmcgui . Dialog ( )
o0oOoO00o = xbmcgui . DialogProgress ( )
i1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
if 64 - 64: oo % O0Oooo00
Ooo0 = xbmc . translatePath ( 'special://home/' )
oo00000o0 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'controls.txt' ) )
I11i1i11i1I = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'disclaimer.txt' ) )
Iiii = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'agreed.txt' ) )
OOO0O = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o ) )
oo0ooO0oOOOOo = xbmc . translatePath ( os . path . join ( OOO0O , 'history.xml' ) )
oO000OoOoo00o = xbmc . translatePath ( os . path . join ( OOO0O , 'favourites.xml' ) )
iiiI11 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'settings.xml' ) )
OOooO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/settings_default.xml' ) )
if 58 - 58: i11iiII + OooooO0oOO + oOo0 / oo0Ooo0
def I1I11I1I1I ( ) :
 if 90 - 90: i1IIiiiii + i1iIIIiI1I - OoO000 % OooOoO0Oo + iiIIiIiIi
 if not os . path . exists ( Iiii ) :
  i1I11 = open ( I11i1i11i1I , mode = 'r' ) ; iI = i1I11 . read ( ) ; i1I11 . close ( )
  common . TextBoxes ( "%s" % iI )
  o0O00oooo = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]Do you agree to the terms and conditions of this addon?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[COLOR red]NO[/COLOR]' )
  if o0O00oooo == 1 :
   if not os . path . exists ( OOO0O ) :
    os . makedirs ( OOO0O )
   open ( Iiii , 'w' )
  else :
   sys . exit ( 0 )
   if 67 - 67: OO0oOoo / oo0Oo00Oo0 % II % O0Oooo00
 if not os . path . exists ( OOO0O ) :
  o0O00oooo = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , "[COLOR white]We can see that this is your first time using the addon. Would you like to enable the parental controls now?[/COLOR]" , "" , yeslabel = '[COLOR red]NO[/COLOR]' , nolabel = '[COLOR lime]YES[/COLOR]' )
  if o0O00oooo == 0 :
   I11i1I ( )
  else :
   os . makedirs ( OOO0O )
   if 83 - 83: i1iIIIiI1I + I1i1iI1i * OooooO0oOO % O0Oooo00 + i1iIIIiI1I
 elif os . path . exists ( oo00000o0 ) :
  Ii1iIIIi1ii = common . _get_keyboard ( heading = "Please Enter Your Password" )
  if ( not Ii1iIIIi1ii ) :
   Ooo . ok ( Oo0Ooo , "Sorry, no password was entered." )
   sys . exit ( 0 )
  o0oo0o0O00OO = Ii1iIIIi1ii
  if 80 - 80: Oo0ooO0oo0oO
  oOOO0o0o = open ( oo00000o0 , "r" )
  iiI1 = re . compile ( r'<password>(.+?)</password>' )
  for i11Iiii in oOOO0o0o :
   file = iiI1 . findall ( i11Iiii )
   for iII1i1I1II in file :
    i1IiIiiI = base64 . b64decode ( iII1i1I1II )
    if not i1IiIiiI == o0oo0o0O00OO :
     if not iII1i1I1II == o0oo0o0O00OO :
      Ooo . ok ( Oo0Ooo , "Sorry, the password you entered was incorrect." )
      sys . exit ( 0 )
      if 31 - 31: OoO000 . OoO000 - OooooO0oOO / O0Oooo00 + oo0Oo00Oo0 * II
 if not os . path . isfile ( iiiI11 ) :
  shutil . copyfile ( OOooO , iiiI11 )
  if 63 - 63: OO0oOoo % Oo0ooO0oo0oO / O0oo0OO0 - O0oo0OO0
 iIii11I = plugintools . get_setting ( "download_location" )
 OOO0OOO00oo = xbmc . translatePath ( iIii11I )
 if not os . path . exists ( OOO0OOO00oo ) :
  os . makedirs ( OOO0OOO00oo )
  if 31 - 31: I1i1iI1i - i1IIiiiii . OO0oOoo % i11iiII - iii1I1I
 iii11 = plugintools . get_setting ( "history_setting" )
 if iii11 == 'true' :
  if not os . path . isfile ( oo0ooO0oOOOOo ) :
   i1I11 = open ( oo0ooO0oOOOOo , 'w' )
   i1I11 . write ( '#START OF FILE#' )
   i1I11 . close ( )
  if not os . path . isfile ( oO000OoOoo00o ) :
   i1I11 = open ( oO000OoOoo00o , 'w' )
   i1I11 . write ( '#START OF FILE#' )
   i1I11 . close ( )
   if 58 - 58: i1IIiiiii * i11iIiiIii / i11iiII % OO0oOoo - oOo0 / oo0Ooo0
 common . addDir ( "[COLOR red]SEARCH ALL WESBITES[/COLOR]" , "url" , 100 , iiiii , O0O0OO0O0O0 )
 common . addDir ( "[COLOR pink]Xhamster.com[/COLOR]" , OoI1Ii11I1Ii1i , 10 , ooo0OO , II1 )
 common . addDir ( "[COLOR pink]Chaturbate.com[/COLOR]" , OoI1Ii11I1Ii1i , 20 , O00ooooo00 , I1IiiI )
 common . addDir ( "[COLOR pink]XNXX.com[/COLOR]" , OoI1Ii11I1Ii1i , 30 , IIi1IiiiI1Ii , I11i11Ii )
 common . addDir ( "[COLOR pink]RedTube.com[/COLOR]" , OoI1Ii11I1Ii1i , 41 , oO00oOo , OOOo0 )
 common . addDir ( "[COLOR pink]PornHD.com[/COLOR]" , OoI1Ii11I1Ii1i , 50 , Oooo000o , IiIi11iIIi1Ii )
 common . addDir ( "[COLOR pink]Porn.com[/COLOR]" , OoI1Ii11I1Ii1i , 60 , Oo0O , IiI )
 common . addDir ( "[COLOR pink]YouPorn.com[/COLOR]" , OoI1Ii11I1Ii1i , 70 , ooOo , Oo )
 common . addDir ( "[COLOR pink]PornFun.com[/COLOR]" , OoI1Ii11I1Ii1i , 80 , o0O , IiiIII111iI )
 common . addDir ( "[COLOR deeppink]Your History[/COLOR]" , OoI1Ii11I1Ii1i , 101 , iiiii , O0O0OO0O0O0 )
 common . addDir ( "[COLOR deeppink]Your Favourites[/COLOR]" , OoI1Ii11I1Ii1i , 102 , iiiii , O0O0OO0O0O0 )
 common . addDir ( "[COLOR deeppink]Your Downloads[/COLOR]" , OoI1Ii11I1Ii1i , 105 , iiiii , O0O0OO0O0O0 )
 common . addLink ( "[COLOR white]Twitter Support: [/COLOR][COLOR pink]@EchoCoder[/COLOR]" , OoI1Ii11I1Ii1i , 999 , iiiii , O0O0OO0O0O0 )
 if 50 - 50: II
 if not os . path . exists ( oo00000o0 ) :
  common . addDir ( "[COLOR white]PARENTAL CONTROLS - [COLOR red]OFF[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
 else :
  common . addDir ( "[COLOR white]PARENTAL CONTROLS - [COLOR lime]ON[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
  if 34 - 34: II * I1i1iI1i % OooOoO0Oo * i11iiII - II
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 33 - 33: OooooO0oOO + i1IIiiiii * O0Oooo00 - oo / oo0Ooo0 % OoO000
def II1i1IiiIIi11 ( ) :
 if 47 - 47: OooOoO0Oo
 Ii11iII1 = ''
 Oo0O0O0ooO0O = xbmc . Keyboard ( Ii11iII1 , 'Enter Search Term' )
 Oo0O0O0ooO0O . doModal ( )
 if Oo0O0O0ooO0O . isConfirmed ( ) :
  IIIIii = Oo0O0O0ooO0O . getText ( )
  O0o0 = IIIIii
  Ii11iII1 = IIIIii . replace ( ' ' , '+' )
  if len ( Ii11iII1 ) > 1 :
   try :
    o0oOoO00o . create ( Oo0Ooo , '[COLOR white]Searching: [/COLOR] [COLOR red]YouPorn[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0o0 . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]1 of 7[/COLOR]' )
    OO00Oo = "http://www.youporn.com/search/?query=" + Ii11iII1 . lower ( )
    OO00Oo = 'split|' + OO00Oo
    o0oOoO00o . update ( 15 )
    youporn . GET_CONTENT ( OO00Oo )
    OO00Oo = "http://www.xnxx.com/?k=" + Ii11iII1 . lower ( )
    OO00Oo = 'split|' + OO00Oo
    o0oOoO00o . update ( 30 , '[COLOR white]Searching: [/COLOR] [COLOR red]XNXX[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0o0 . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]2 of 7[/COLOR]' )
    xnxx . GET_CONTENT ( OO00Oo )
    OO00Oo = "https://xhamster.com/search.php?from=&new=&q=" + Ii11iII1 . lower ( ) + "&qcat=video"
    OO00Oo = 'split|' + OO00Oo
    o0oOoO00o . update ( 45 , '[COLOR white]Searching: [/COLOR] [COLOR red]Xhamster[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0o0 . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]3 of 7[/COLOR]' )
    xhamster . GET_CONTENT ( OO00Oo )
    OO00Oo = "http://www.pornhd.com/search?search=" + Ii11iII1 . lower ( )
    OO00Oo = 'split|' + OO00Oo
    o0oOoO00o . update ( 60 , '[COLOR white]Searching: [/COLOR] [COLOR red]PornHD[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0o0 . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]4 of 7[/COLOR]' )
    pornhd . GET_CONTENT ( OO00Oo )
    OO00Oo = "http://www.porn.com/videos/search?q=" + Ii11iII1 . lower ( )
    OO00Oo = 'split|' + OO00Oo
    o0oOoO00o . update ( 75 , '[COLOR white]Searching: [/COLOR] [COLOR red]Porn.com[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0o0 . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]5 of 7[/COLOR]' )
    porncom . GET_CONTENT ( OO00Oo )
    OO00Oo = "http://www.redtube.com/?search=" + Ii11iII1 . lower ( )
    OO00Oo = 'split|' + OO00Oo
    o0oOoO00o . update ( 90 , '[COLOR white]Searching: [/COLOR] [COLOR red]RedTube[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0o0 . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]6 of 7[/COLOR]' )
    redtube . GET_CONTENT ( OO00Oo )
    OO00Oo = "http://pornfun.com/search/?q=" + Ii11iII1 . lower ( )
    OO00Oo = 'split|' + OO00Oo
    o0oOoO00o . update ( 95 , '[COLOR white]Searching: [/COLOR] [COLOR red]PornFun[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0o0 . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]7 of 7[/COLOR]' )
    pornfun . GET_CONTENT ( OO00Oo )
    o0oOoO00o . close ( )
   except :
    Ooo . ok ( Oo0Ooo , '[COLOR pink]Sorry, there was an error searching for ' + Ii11iII1 . lower ( ) + ' please try again later.[/COLOR]' )
    quit ( )
  else : quit ( )
  if 51 - 51: iiIIiIiIi * OooooO0oOO + i1iIIIiI1I + O0Oooo00
def o0O0O00 ( ) :
 if 86 - 86: i1iIIIiI1I / iiIIiIiIi % i11iIiiIii
 I11IiI1I11i1i = 0
 if not os . path . exists ( oo00000o0 ) :
  I11IiI1I11i1i = 1
  common . addLink ( "[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR red]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  common . addLink ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
 else :
  oOOO0o0o = open ( oo00000o0 , "r" )
  iiI1 = re . compile ( r'<password>(.+?)</password>' )
  for i11Iiii in oOOO0o0o :
   file = iiI1 . findall ( i11Iiii )
   for iII1i1I1II in file :
    i1IiIiiI = base64 . b64decode ( iII1i1I1II )
    I11IiI1I11i1i = 1
    common . addLink ( "[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR lime]ON[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    common . addLink ( "[COLOR white]Current Password - [/COLOR][COLOR orangered]" + str ( i1IiIiiI ) + "[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    common . addLink ( "[COLOR lime]Change Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
    common . addLink ( "[COLOR red]Disable Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
    if 38 - 38: OooooO0oOO
 if I11IiI1I11i1i == 0 :
  common . addLink ( "[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR red]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  common . addLink ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
  if 57 - 57: iii1I1I / oo0Ooo0 * OO0oOoo / i11iiII . I1i1iI1i
def i11iIIIIIi1 ( ) :
 if 20 - 20: Oo0ooO0oo0oO + oOo0 - oo0Oo00Oo0
 iii11 = plugintools . get_setting ( "history_setting" )
 if 30 - 30: I1i1iI1i - i1IIiiiii - i11iIiiIii % i11iiII - I1i1iI1i * OoO000
 if iii11 == "true" :
  common . addLink ( '[COLOR deeppink]Clear History[/COLOR]' , OoI1Ii11I1Ii1i , 104 , iiiii , O0O0OO0O0O0 )
  common . addLink ( '[COLOR red]Disable History[/COLOR]' , OoI1Ii11I1Ii1i , 106 , iiiii , O0O0OO0O0O0 )
  common . addLink ( '###########################################' , OoI1Ii11I1Ii1i , 999 , iiiii , O0O0OO0O0O0 )
  if 61 - 61: oo0Ooo0 - i1iIIIiI1I % i1IIiiiii
  i1I11 = open ( oo0ooO0oOOOOo , mode = 'r' ) ; iI = i1I11 . read ( ) ; i1I11 . close ( )
  iI = iI . replace ( '\n' , '' )
  OOoOO0oo0ooO = re . compile ( '<item>(.+?)</item>' ) . findall ( iI )
  for O0o0O00Oo0o0 in OOoOO0oo0ooO :
   O00O0oOO00O00 = re . compile ( '<date>(.+?)</date>' ) . findall ( O0o0O00Oo0o0 ) [ 0 ]
   time = re . compile ( '<time>(.+?)</time>' ) . findall ( O0o0O00Oo0o0 ) [ 0 ]
   i1Oo00 = re . compile ( '<name>(.+?)</name>' ) . findall ( O0o0O00Oo0o0 ) [ 0 ]
   OO00Oo = re . compile ( '<link>(.+?)</link>' ) . findall ( O0o0O00Oo0o0 ) [ 0 ]
   i1i = re . compile ( '<site>(.+?)</site>' ) . findall ( O0o0O00Oo0o0 ) [ 0 ]
   iiI111I1iIiI = re . compile ( '<icon>(.+?)</icon>' ) . findall ( O0o0O00Oo0o0 ) [ 0 ]
   OO00Oo = i1Oo00 + '|SPLIT|' + OO00Oo + '|SPLIT|' + i1i + '|SPLIT|' + iiI111I1iIiI + '|SPLIT|' + OO00Oo
   if 41 - 41: oo . oo0Oo00Oo0 + iii1I1I * OooooO0oOO % oo * oo
   common . addLink ( '[COLOR pink]' + O00O0oOO00O00 + ' | ' + '[/COLOR][COLOR deeppink]' + time + '[/COLOR] - [COLOR red]' + i1i + '[/COLOR][COLOR pink] - ' + i1Oo00 + '[/COLOR]' , OO00Oo , 800 , iiI111I1iIiI , O0O0OO0O0O0 )
 else : common . addLink ( '[COLOR red]Enable History Monitoring[/COLOR]' , OoI1Ii11I1Ii1i , 106 , iiiii , O0O0OO0O0O0 )
 if 19 - 19: OooOoO0Oo
def IIi1iiIi1 ( ) :
 if 21 - 21: II * O00oOoOoO0o0O
 common . addLink ( '[COLOR deeppink]Your Favourites[/COLOR]' , OoI1Ii11I1Ii1i , 999 , iiiii , O0O0OO0O0O0 )
 common . addLink ( '###########################################' , OoI1Ii11I1Ii1i , 999 , iiiii , O0O0OO0O0O0 )
 if 91 - 91: iiIIiIiIi
 i1I11 = open ( oO000OoOoo00o , mode = 'r' ) ; iI = i1I11 . read ( ) ; i1I11 . close ( )
 iI = iI . replace ( '\n' , '' )
 OOoOO0oo0ooO = re . compile ( '<item>(.+?)</item>' ) . findall ( iI )
 for O0o0O00Oo0o0 in OOoOO0oo0ooO :
  i1Oo00 = re . compile ( '<name>(.+?)</name>' ) . findall ( O0o0O00Oo0o0 ) [ 0 ]
  OO00Oo = re . compile ( '<link>(.+?)</link>' ) . findall ( O0o0O00Oo0o0 ) [ 0 ]
  i1i = re . compile ( '<site>(.+?)</site>' ) . findall ( O0o0O00Oo0o0 ) [ 0 ]
  iiI111I1iIiI = re . compile ( '<icon>(.+?)</icon>' ) . findall ( O0o0O00Oo0o0 ) [ 0 ]
  OO00Oo = i1Oo00 + '|SPLIT|' + OO00Oo + '|SPLIT|' + i1i + '|SPLIT|' + iiI111I1iIiI + '|SPLIT|' + OO00Oo
  common . addLink ( '[COLOR red]' + i1i + '[/COLOR][COLOR pink] - ' + i1Oo00 + '[/COLOR]' , OO00Oo , 103 , iiI111I1iIiI , O0O0OO0O0O0 )
  if 15 - 15: I1i1iI1i
def Ii ( name , url , iconimage ) :
 if 79 - 79: O0oo0OO0 / iii1I1I
 OO0OoO0o00 = url
 ooOO0O0ooOooO , oOOOo00O00oOo , iiIIIi , ooo00OOOooO , url = url . split ( '|SPLIT|' )
 if 67 - 67: i1iIIIiI1I * oo0Ooo0 * oOo0 + i1IIiiiii / Oo0ooO0oo0oO
 Ii11iII1 = '\n<item>\n<name>' + ooOO0O0ooOooO + '</name>\n<link>' + oOOOo00O00oOo + '</link>\n<site>' + iiIIIi + '</site>\n<icon>' + ooo00OOOooO + '</icon>\n</item>\n'
 if 11 - 11: OoO000 + OooOoO0Oo - oo0Oo00Oo0 * oo0Ooo0 % i11iIiiIii - OO0oOoo
 o0O00oooo = Ooo . select ( "[COLOR red][B]Please select an option[/B][/COLOR]" , [ '[COLOR pink][B]Watch Video[/B][/COLOR]' , '[COLOR pink][B]Remove from Favourites[/B][/COLOR]' ] )
 if 83 - 83: i1iIIIiI1I / II
 if o0O00oooo == 0 :
  iIIiIi1iIII1 ( name , OO0OoO0o00 , iconimage )
 else :
  OooOOOOo = open ( oO000OoOoo00o ) . read ( )
  i1I11 = OooOOOOo . replace ( Ii11iII1 , '\n' )
  oo0O0oO = open ( oO000OoOoo00o , mode = 'w' )
  oo0O0oO . write ( str ( i1I11 ) )
  oo0O0oO . close ( )
  xbmc . executebuiltin ( "Container.Refresh" )
  quit ( )
  if 60 - 60: II
def iii1i ( name , url , iconimage ) :
 if 39 - 39: OooOoO0Oo - iii1I1I % i11iIiiIii * OO0oOoo . iiIIiIiIi
 OO0OoO0o00 = url
 ooOO0O0ooOooO , oOOOo00O00oOo , iiIIIi , ooo00OOOooO , url = url . split ( '|SPLIT|' )
 if 58 - 58: O0Oooo00 % i11iIiiIii . OooOoO0Oo / oo0Ooo0
 o0O00oooo = Ooo . select ( "[COLOR red][B]Please select an option[/B][/COLOR]" , [ '[COLOR pink][B]Watch Video[/B][/COLOR]' , '[COLOR pink][B]Delete Download[/B][/COLOR]' ] )
 if 84 - 84: OooOoO0Oo . oOo0 / oo - II / O0oo0OO0 / OooooO0oOO
 if o0O00oooo == 0 :
  iIIiIi1iIII1 ( name , OO0OoO0o00 , iconimage )
 else :
  os . remove ( url )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 12 - 12: II * OooOoO0Oo % Oo0ooO0oo0oO % O00oOoOoO0o0O
def IIi1I11I1II ( ) :
 if 63 - 63: O0oo0OO0 - O0Oooo00 . I1i1iI1i / OooooO0oOO . i11iiII / iii1I1I
 if os . path . isfile ( oo0ooO0oOOOOo ) :
  o0O00oooo = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]Would you like to clear all stored history?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[B][COLOR red]NO[/COLOR][/B]' )
  if o0O00oooo == 1 :
   os . remove ( oo0ooO0oOOOOo )
   i1I11 = open ( oo0ooO0oOOOOo , 'w' )
   i1I11 . write ( '#START OF FILE#' )
   i1I11 . close ( )
 xbmc . executebuiltin ( "Container.Refresh" )
 if 84 - 84: iiIIiIiIi
def OOO00O0O ( ) :
 if 33 - 33: iii1I1I . iiIIiIiIi . II
 iIii11I = plugintools . get_setting ( "download_location" )
 OoOO = xbmc . translatePath ( iIii11I )
 common . addLink ( '[COLOR deeppink]Download Location: [/COLOR]' , OoI1Ii11I1Ii1i , 999 , iiiii , O0O0OO0O0O0 )
 common . addLink ( OoOO , OoI1Ii11I1Ii1i , 999 , iiiii , O0O0OO0O0O0 )
 common . addLink ( '[COLOR red]Change Download Location[/COLOR]' , OoI1Ii11I1Ii1i , 106 , iiiii , O0O0OO0O0O0 )
 common . addLink ( '###########################################' , OoI1Ii11I1Ii1i , 999 , iiiii , O0O0OO0O0O0 )
 if 53 - 53: oo
 iI1Iii = [ '.mp4' , '.avi' , '.mkv' ]
 if 68 - 68: i1IIiiiii % OO0oOoo
 for file in os . listdir ( OoOO ) :
  for ooO00OO0 in iI1Iii :
   if file . endswith ( ooO00OO0 ) :
    OO00Oo = xbmc . translatePath ( os . path . join ( OoOO , file ) )
    i11111IIIII = file + '|SPLIT|' + OO00Oo + '|SPLIT|Downloaded|SPLIT|None|SPLIT|' + OO00Oo
    common . addLink ( '[COLOR pink]' + file + '[/COLOR]' , i11111IIIII , 107 , iiiii , O0O0OO0O0O0 )
    if 19 - 19: i11iiII * Oo0ooO0oo0oO
def ii111iI1iIi1 ( ) :
 if 78 - 78: O0Oooo00 . i1IIiiiii + O0Oooo00 / i1iIIIiI1I / O0Oooo00
 iIii11I = plugintools . get_setting ( "download_location" )
 oO0O00OoOO0 = Ooo . browse ( 3 , Oo0Ooo , 'files' , '' , False , False , Ooo0 )
 OooOOOOo = open ( iiiI11 ) . read ( )
 i1I11 = OooOOOOo . replace ( iIii11I , oO0O00OoOO0 )
 oo0O0oO = open ( iiiI11 , mode = 'w' )
 oo0O0oO . write ( str ( i1I11 ) )
 oo0O0oO . close ( )
 xbmc . executebuiltin ( "Container.Refresh" )
 if 82 - 82: I1i1iI1i . iiIIiIiIi - O00oOoOoO0o0O - iiIIiIiIi * I1i1iI1i
def ooO0oOOooOo0 ( name , url , iconimage ) :
 if 38 - 38: OO0oOoo
 ooOO0O0ooOooO , oOOOo00O00oOo , iiIIIi , ooo00OOOooO , url = url . split ( '|SPLIT|' )
 name = ooOO0O0ooOooO
 Ooo00o0Oooo = datetime . datetime . now ( ) . strftime ( "%d-%m-%Y" )
 OOooooO0Oo = datetime . datetime . now ( ) . strftime ( "%H:%M" )
 Ii11iII1 = '\n<item>\n<date>' + Ooo00o0Oooo + '</date>\n<time>' + OOooooO0Oo + '</time>\n<name>' + ooOO0O0ooOooO + '</name>\n<link>' + oOOOo00O00oOo + '</link>\n<site>' + iiIIIi + '</site>\n<icon>' + ooo00OOOooO + '</icon>\n</item>\n'
 ooOO0O0ooOooO = open ( oo0ooO0oOOOOo ) . read ( )
 oOOOo00O00oOo = ooOO0O0ooOooO . replace ( '#START OF FILE#' , '#START OF FILE#' + Ii11iII1 )
 i1I11 = open ( oo0ooO0oOOOOo , mode = 'w' )
 i1I11 . write ( str ( oOOOo00O00oOo ) )
 i1I11 . close ( )
 if 91 - 91: OooooO0oOO . O00oOoOoO0o0O / oo0Ooo0 + Oo0ooO0oo0oO
 if iconimage == "None" :
  iconimage = iiiii
 I1i = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , I1i , False )
 if 53 - 53: oOo0 * i11iiII + oo0Oo00Oo0 - I1i1iI1i
def iIIiIi1iIII1 ( name , url , iconimage ) :
 if 2 - 2: i1iIIIiI1I + OoO000 - II % OooooO0oOO . OooOoO0Oo
 ooOO0O0ooOooO , oOOOo00O00oOo , iiIIIi , ooo00OOOooO , url = url . split ( '|SPLIT|' )
 name = ooOO0O0ooOooO
 Ooo00o0Oooo = datetime . datetime . now ( ) . strftime ( "%d-%m-%Y" )
 OOooooO0Oo = datetime . datetime . now ( ) . strftime ( "%H:%M" )
 Ii11iII1 = '\n<item>\n<date>' + Ooo00o0Oooo + '</date>\n<time>' + OOooooO0Oo + '</time>\n<name>' + ooOO0O0ooOooO + '</name>\n<link>' + oOOOo00O00oOo + '</link>\n<site>' + iiIIIi + '</site>\n<icon>' + ooo00OOOooO + '</icon>\n</item>\n'
 ooOO0O0ooOooO = open ( oo0ooO0oOOOOo ) . read ( )
 oOOOo00O00oOo = ooOO0O0ooOooO . replace ( '#START OF FILE#' , '#START OF FILE#' + Ii11iII1 )
 i1I11 = open ( oo0ooO0oOOOOo , mode = 'w' )
 i1I11 . write ( str ( oOOOo00O00oOo ) )
 i1I11 . close ( )
 if 18 - 18: i1IIiiiii + OooOoO0Oo - OoO000 . I1i1iI1i + i11iIiiIii
 if iconimage == "None" :
  iconimage = iiiii
 I1i = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , I1i , False )
 if 20 - 20: OO0oOoo
def I11i1I ( ) :
 if 52 - 52: I1i1iI1i - O0oo0OO0 % OoO000 + II * oo . iiIIiIiIi
 Ii1iIIIi1ii = common . _get_keyboard ( heading = "Please Set Password" )
 if ( not Ii1iIIIi1ii ) :
  Ooo . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 o0oo0o0O00OO = Ii1iIIIi1ii
 if 75 - 75: oo0Oo00Oo0 + i11iiII + OooooO0oOO * i1iIIIiI1I % oo0Ooo0 . OooOoO0Oo
 Ii1iIIIi1ii = common . _get_keyboard ( heading = "Please Confirm Your Password" )
 if ( not Ii1iIIIi1ii ) :
  Ooo . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 oO = Ii1iIIIi1ii
 if 31 - 31: i1IIiiiii + i11iIiiIii + oo * oo0Oo00Oo0
 if not os . path . exists ( oo00000o0 ) :
  if not os . path . exists ( OOO0O ) :
   os . makedirs ( OOO0O )
  open ( oo00000o0 , 'w' )
  if 28 - 28: iii1I1I * oo - i1IIiiiii % O00oOoOoO0o0O * OoO000 - i11iIiiIii
  if o0oo0o0O00OO == oO :
   IIII11 = base64 . b64encode ( o0oo0o0O00OO )
   i1I11 = open ( oo00000o0 , 'w' )
   i1I11 . write ( '<password>' + str ( IIII11 ) + '</password>' )
   i1I11 . close ( )
   Ooo . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   Ooo . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
 else :
  os . remove ( oo00000o0 )
  if 38 - 38: OooooO0oOO - oo0Ooo0 + O00oOoOoO0o0O / i11iiII % oo
  if o0oo0o0O00OO == oO :
   IIII11 = base64 . b64encode ( o0oo0o0O00OO )
   i1I11 = open ( oo00000o0 , 'w' )
   i1I11 . write ( '<password>' + str ( IIII11 ) + '</password>' )
   i1I11 . close ( )
   Ooo . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   Ooo . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
   if 57 - 57: O0Oooo00 / oo0Oo00Oo0
def Ii1I1Ii ( ) :
 if 69 - 69: II / OooooO0oOO . iiIIiIiIi * OO0oOoo % OoO000 - OooooO0oOO
 try :
  os . remove ( oo00000o0 )
  Ooo . ok ( Oo0Ooo , 'Parental controls have been disabled.' )
  xbmc . executebuiltin ( "Container.Refresh" )
 except :
  Ooo . ok ( Oo0Ooo , 'There was an error disabling the parental controls.' )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 13 - 13: OoO000 . i11iIiiIii
def oOOoo00O00o ( ) :
 O0O00Oo = [ ]
 oooooo0O000o = sys . argv [ 2 ]
 if len ( oooooo0O000o ) >= 2 :
  OoO = sys . argv [ 2 ]
  ooO0O0O0ooOOO = OoO . replace ( '?' , '' )
  if ( OoO [ len ( OoO ) - 1 ] == '/' ) :
   OoO = OoO [ 0 : len ( OoO ) - 2 ]
  oOOo0O00o = ooO0O0O0ooOOO . split ( '&' )
  O0O00Oo = { }
  for iIiIi11 in range ( len ( oOOo0O00o ) ) :
   OOO = { }
   OOO = oOOo0O00o [ iIiIi11 ] . split ( '=' )
   if ( len ( OOO ) ) == 2 :
    O0O00Oo [ OOO [ 0 ] ] = OOO [ 1 ]
    if 32 - 32: Oo0ooO0oo0oO / I1i1iI1i . oo
 return O0O00Oo
 if 62 - 62: O0oo0OO0 * II
OoO = oOOoo00O00o ( ) ; oOOOoo0O0oO = None ; OO00Oo = None ; iIII1I111III = None ; iiI111I1iIiI = None ; IIo0o0O0O00oOOo = None
try : oOOOoo0O0oO = urllib . unquote_plus ( OoO [ "name" ] )
except : pass
try : OO00Oo = urllib . unquote_plus ( OoO [ "url" ] )
except : pass
try : iIII1I111III = int ( OoO [ "mode" ] )
except : pass
try : iiI111I1iIiI = urllib . unquote_plus ( OoO [ "iconimage" ] )
except : pass
try : IIo0o0O0O00oOOo = urllib . quote_plus ( OoO [ "fanartimage" ] )
except : pass
if 14 - 14: i11iiII + oo0Ooo0
if iIII1I111III == None or OO00Oo == None or len ( OO00Oo ) < 1 : I1I11I1I1I ( )
if 52 - 52: O0oo0OO0 - oo0Oo00Oo0
elif iIII1I111III == 10 : xhamster . MAIN_MENU ( )
elif iIII1I111III == 11 : xhamster . GET_CONTENT ( OO00Oo )
elif iIII1I111III == 12 : xhamster . SEARCH ( )
elif iIII1I111III == 13 : xhamster . PLAY_URL ( oOOOoo0O0oO , OO00Oo , iiI111I1iIiI )
elif iIII1I111III == 20 : chaturbate . MAIN_MENU ( )
elif iIII1I111III == 21 : chaturbate . GET_CONTENT ( OO00Oo )
elif iIII1I111III == 22 : chaturbate . SEARCH ( )
elif iIII1I111III == 23 : chaturbate . PLAY_URL ( oOOOoo0O0oO , OO00Oo , iiI111I1iIiI )
elif iIII1I111III == 30 : xnxx . MAIN_MENU ( )
elif iIII1I111III == 31 : xnxx . GET_CONTENT ( OO00Oo )
elif iIII1I111III == 32 : xnxx . SEARCH ( )
elif iIII1I111III == 33 : xnxx . PLAY_URL ( oOOOoo0O0oO , OO00Oo , iiI111I1iIiI )
elif iIII1I111III == 34 : xnxx . PICTURE_MENU ( )
elif iIII1I111III == 35 : xnxx . PICTURE_CONTENT ( OO00Oo )
elif iIII1I111III == 36 : xnxx . SCRAPE_GALLERY ( OO00Oo )
elif iIII1I111III == 37 : xnxx . DISPLAY_PICTURE ( OO00Oo )
elif iIII1I111III == 38 : xnxx . STORY_MENU ( )
elif iIII1I111III == 39 : xnxx . LIST_STORIES ( OO00Oo )
elif iIII1I111III == 40 : xnxx . DISPLAY_STORY ( OO00Oo )
elif iIII1I111III == 41 : redtube . MAIN_MENU ( )
elif iIII1I111III == 42 : redtube . GET_CONTENT ( OO00Oo )
elif iIII1I111III == 43 : redtube . SEARCH ( )
elif iIII1I111III == 44 : redtube . PLAY_URL ( oOOOoo0O0oO , OO00Oo , iiI111I1iIiI )
elif iIII1I111III == 50 : pornhd . MAIN_MENU ( )
elif iIII1I111III == 51 : pornhd . GET_CONTENT ( OO00Oo )
elif iIII1I111III == 52 : pornhd . SEARCH ( )
elif iIII1I111III == 53 : pornhd . PLAY_URL ( oOOOoo0O0oO , OO00Oo , iiI111I1iIiI )
elif iIII1I111III == 60 : porncom . MAIN_MENU ( )
elif iIII1I111III == 61 : porncom . GET_CONTENT ( OO00Oo )
elif iIII1I111III == 62 : porncom . SEARCH ( )
elif iIII1I111III == 63 : porncom . PLAY_URL ( oOOOoo0O0oO , OO00Oo , iiI111I1iIiI )
elif iIII1I111III == 70 : youporn . MAIN_MENU ( )
elif iIII1I111III == 71 : youporn . GET_CONTENT ( OO00Oo )
elif iIII1I111III == 72 : youporn . SEARCH ( )
elif iIII1I111III == 73 : youporn . PLAY_URL ( oOOOoo0O0oO , OO00Oo , iiI111I1iIiI )
elif iIII1I111III == 80 : pornfun . MAIN_MENU ( )
elif iIII1I111III == 81 : pornfun . GET_CONTENT ( OO00Oo )
elif iIII1I111III == 82 : pornfun . SEARCH ( )
elif iIII1I111III == 83 : pornfun . PLAY_URL ( oOOOoo0O0oO , OO00Oo , iiI111I1iIiI )
elif iIII1I111III == 100 : II1i1IiiIIi11 ( )
elif iIII1I111III == 101 : i11iIIIIIi1 ( )
elif iIII1I111III == 102 : IIi1iiIi1 ( )
elif iIII1I111III == 103 : Ii ( oOOOoo0O0oO , OO00Oo , iiI111I1iIiI )
elif iIII1I111III == 104 : IIi1I11I1II ( )
elif iIII1I111III == 105 : OOO00O0O ( )
elif iIII1I111III == 106 : plugintools . open_settings_dialog ( ) ; xbmc . executebuiltin ( 'Container.Refresh' )
elif iIII1I111III == 107 : iii1i ( oOOOoo0O0oO , OO00Oo , iiI111I1iIiI )
elif iIII1I111III == 800 : iIIiIi1iIII1 ( oOOOoo0O0oO , OO00Oo , iiI111I1iIiI )
elif iIII1I111III == 900 : o0O0O00 ( )
elif iIII1I111III == 901 : I11i1I ( )
elif iIII1I111III == 902 : Ii1I1Ii ( )
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )