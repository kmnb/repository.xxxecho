import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , shutil
import base64 , time , datetime
from resources . lib . modules import plugintools
from resources . lib . modules import common
from resources . lib . scrapers import chaturbate
from resources . lib . scrapers import xnxx
from resources . lib . scrapers import youporn
from resources . lib . scrapers import porncom
from resources . lib . scrapers import pornhd
from resources . lib . scrapers import redtube
from resources . lib . scrapers import xhamster
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.xxx-o-dus'
Oo0Ooo = '[COLOR red]XXX-O-DUS[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/xhamster/icon.png' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/xhamster/fanart.jpg' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/chaturbate/icon.png' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/chaturbate/fanart.jpg' ) )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/xnxx/icon.png' ) )
I11i11Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/xnxx/fanart.jpg' ) )
oO00oOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/redtube/icon.png' ) )
OOOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/redtube/fanart.jpg' ) )
Oooo000o = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/pornhd/icon.png' ) )
IiIi11iIIi1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/pornhd/fanart.jpg' ) )
Oo0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/porncom/icon.png' ) )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/porncom/fanart.jpg' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/youporn/icon.png' ) )
Oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/youporn/fanart.jpg' ) )
if 67 - 67: O00ooOO . I1iII1iiII
iI1Ii11111iIi = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
i1i1II = xbmcgui . Dialog ( )
O0oo0OO0 = xbmcgui . DialogProgress ( )
I1i1iiI1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
if 24 - 24: oOOOO0o0o
Ii1iI = xbmc . translatePath ( 'special://home/' )
OoI1Ii11I1Ii1i = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'controls.txt' ) )
Ooo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'disclaimer.txt' ) )
o0oOoO00o = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'agreed.txt' ) )
i1 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o ) )
oOOoo00O0O = xbmc . translatePath ( os . path . join ( i1 , 'history.xml' ) )
i1111 = xbmc . translatePath ( os . path . join ( i1 , 'favourites.xml' ) )
i11 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'settings.xml' ) )
I11 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/settings_default.xml' ) )
if 98 - 98: I1111 * o0o0Oo0oooo0 / I1I1i1 * oO0 / IIIi1i1I
def OOoOoo00oo ( ) :
 if 41 - 41: i11IiIiiIIIII / IiiIII111ii / i1iIIi1
 if not os . path . exists ( o0oOoO00o ) :
  ii11iIi1I = open ( Ooo , mode = 'r' ) ; iI111I11I1I1 = ii11iIi1I . read ( ) ; ii11iIi1I . close ( )
  common . TextBoxes ( "%s" % iI111I11I1I1 )
  OOooO0OOoo = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]Do you agree to the terms and conditions of this addon?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[COLOR red]NO[/COLOR]' )
  if OOooO0OOoo == 1 :
   if not os . path . exists ( i1 ) :
    os . makedirs ( i1 )
   open ( o0oOoO00o , 'w' )
  else :
   sys . exit ( 0 )
   if 29 - 29: o00o / IiI1I1
 if not os . path . exists ( i1 ) :
  OOooO0OOoo = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , "[COLOR white]We can see that this is your first time using the addon. Would you like to enable the parental controls now?[/COLOR]" , "" , yeslabel = '[COLOR red]NO[/COLOR]' , nolabel = '[COLOR lime]YES[/COLOR]' )
  if OOooO0OOoo == 0 :
   OoO000 ( )
  else :
   os . makedirs ( i1 )
   if 42 - 42: oOoO - iiIiIIi % iI - I11iii / OO0O00
 elif os . path . exists ( OoI1Ii11I1Ii1i ) :
  ii1 = common . _get_keyboard ( heading = "Please Enter Your Password" )
  if ( not ii1 ) :
   i1i1II . ok ( Oo0Ooo , "Sorry, no password was entered." )
   sys . exit ( 0 )
  o0oO0o00oo = ii1
  if 32 - 32: I1 * I1iII1iiII - I11iii % I1iII1iiII - I1
  oOOO00o = open ( OoI1Ii11I1Ii1i , "r" )
  O0O00o0OOO0 = re . compile ( r'<password>(.+?)</password>' )
  for Ii1iIIIi1ii in oOOO00o :
   file = O0O00o0OOO0 . findall ( Ii1iIIIi1ii )
   for o0oo0o0O00OO in file :
    o0oO = base64 . b64decode ( o0oo0o0O00OO )
    if not o0oO == o0oO0o00oo :
     if not o0oo0o0O00OO == o0oO0o00oo :
      i1i1II . ok ( Oo0Ooo , "Sorry, the password you entered was incorrect." )
      sys . exit ( 0 )
      if 48 - 48: oOoO + oOoO / o0o0Oo0oooo0 / I1iII1iiII
 if not os . path . isfile ( i11 ) :
  shutil . copyfile ( I11 , i11 )
  if 20 - 20: IiiIII111ii
 oO00 = plugintools . get_setting ( "download_location" )
 ooo = xbmc . translatePath ( oO00 )
 if not os . path . exists ( ooo ) :
  os . makedirs ( ooo )
  if 18 - 18: IiiIII111ii
 I1i1I1II = plugintools . get_setting ( "history_setting" )
 if I1i1I1II == 'true' :
  if not os . path . isfile ( oOOoo00O0O ) :
   ii11iIi1I = open ( oOOoo00O0O , 'w' )
   ii11iIi1I . write ( '#START OF FILE#' )
   ii11iIi1I . close ( )
  if not os . path . isfile ( i1111 ) :
   ii11iIi1I = open ( i1111 , 'w' )
   ii11iIi1I . write ( '#START OF FILE#' )
   ii11iIi1I . close ( )
   if 45 - 45: OO0O00 . i11IiIiiIIIII
 common . addDir ( "[COLOR red]SEARCH ALL WESBITES[/COLOR]" , "url" , 100 , iiiii , O0O0OO0O0O0 )
 common . addDir ( "[COLOR pink]Xhamster.com[/COLOR]" , iI1Ii11111iIi , 10 , ooo0OO , II1 )
 common . addDir ( "[COLOR pink]Chaturbate.com[/COLOR]" , iI1Ii11111iIi , 20 , O00ooooo00 , I1IiiI )
 common . addDir ( "[COLOR pink]XNXX.com[/COLOR]" , iI1Ii11111iIi , 30 , IIi1IiiiI1Ii , I11i11Ii )
 common . addDir ( "[COLOR pink]RedTube.com[/COLOR]" , iI1Ii11111iIi , 41 , oO00oOo , OOOo0 )
 common . addDir ( "[COLOR pink]PornHD.com[/COLOR]" , iI1Ii11111iIi , 50 , Oooo000o , IiIi11iIIi1Ii )
 common . addDir ( "[COLOR pink]Porn.com[/COLOR]" , iI1Ii11111iIi , 60 , Oo0O , IiI )
 common . addDir ( "[COLOR pink]YouPorn.com[/COLOR]" , iI1Ii11111iIi , 70 , ooOo , Oo )
 common . addDir ( "[COLOR deeppink]Your History[/COLOR]" , iI1Ii11111iIi , 101 , iiiii , O0O0OO0O0O0 )
 common . addDir ( "[COLOR deeppink]Your Favourites[/COLOR]" , iI1Ii11111iIi , 102 , iiiii , O0O0OO0O0O0 )
 common . addDir ( "[COLOR deeppink]Your Downloads[/COLOR]" , iI1Ii11111iIi , 105 , iiiii , O0O0OO0O0O0 )
 common . addLink ( "[COLOR white]Twitter Support: [/COLOR][COLOR pink]@EchoCoder[/COLOR]" , iI1Ii11111iIi , 999 , iiiii , O0O0OO0O0O0 )
 if 83 - 83: o00o . I1iII1iiII . i1iIIi1
 if not os . path . exists ( OoI1Ii11I1Ii1i ) :
  common . addDir ( "[COLOR white]PARENTAL CONTROLS - [COLOR red]OFF[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
 else :
  common . addDir ( "[COLOR white]PARENTAL CONTROLS - [COLOR lime]ON[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
  if 31 - 31: iiIiIIi . iiIiIIi - IiiIII111ii / IIIi1i1I + I1 * I1I1i1
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 63 - 63: OO0O00 % I1111 / oOOOO0o0o - oOOOO0o0o
def iIii11I ( ) :
 if 69 - 69: o00o % OO0O00 - IiiIII111ii + OO0O00 - O00ooOO % oOOOO0o0o
 Iii111II = ''
 iiii11I = xbmc . Keyboard ( Iii111II , 'Enter Search Term' )
 iiii11I . doModal ( )
 if iiii11I . isConfirmed ( ) :
  Iii111II = iiii11I . getText ( ) . replace ( ' ' , '+' )
  if len ( Iii111II ) > 1 :
   Ooo0OO0oOO = "http://www.youporn.com/search/?query=" + Iii111II . lower ( )
   Ooo0OO0oOO = 'split|' + Ooo0OO0oOO
   youporn . GET_CONTENT ( Ooo0OO0oOO )
   Ooo0OO0oOO = "http://www.xnxx.com/?k=" + Iii111II . lower ( )
   Ooo0OO0oOO = 'split|' + Ooo0OO0oOO
   xnxx . GET_CONTENT ( Ooo0OO0oOO )
   Ooo0OO0oOO = "https://xhamster.com/search.php?from=&new=&q=" + Iii111II . lower ( ) + "&qcat=video"
   Ooo0OO0oOO = 'split|' + Ooo0OO0oOO
   xhamster . GET_CONTENT ( Ooo0OO0oOO )
   Ooo0OO0oOO = "http://www.pornhd.com/search?search=" + Iii111II . lower ( )
   Ooo0OO0oOO = 'split|' + Ooo0OO0oOO
   pornhd . GET_CONTENT ( Ooo0OO0oOO )
   Ooo0OO0oOO = "http://www.porn.com/videos/search?q=" + Iii111II . lower ( )
   Ooo0OO0oOO = 'split|' + Ooo0OO0oOO
   porncom . GET_CONTENT ( Ooo0OO0oOO )
   Ooo0OO0oOO = "http://www.redtube.com/?search=" + Iii111II . lower ( )
   Ooo0OO0oOO = 'split|' + Ooo0OO0oOO
   redtube . GET_CONTENT ( Ooo0OO0oOO )
  else : quit ( )
  if 50 - 50: I1I1i1
def Ii1i11IIii1I ( ) :
 if 52 - 52: IiiIII111ii - oOOOO0o0o + iiIiIIi + iiIiIIi - IiiIII111ii / OO0O00
 I1I = 0
 if not os . path . exists ( OoI1Ii11I1Ii1i ) :
  I1I = 1
  common . addLink ( "[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR red]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  common . addLink ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
 else :
  oOOO00o = open ( OoI1Ii11I1Ii1i , "r" )
  O0O00o0OOO0 = re . compile ( r'<password>(.+?)</password>' )
  for Ii1iIIIi1ii in oOOO00o :
   file = O0O00o0OOO0 . findall ( Ii1iIIIi1ii )
   for o0oo0o0O00OO in file :
    o0oO = base64 . b64decode ( o0oo0o0O00OO )
    I1I = 1
    common . addLink ( "[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR lime]ON[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    common . addLink ( "[COLOR white]Current Password - [/COLOR][COLOR orangered]" + str ( o0oO ) + "[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    common . addLink ( "[COLOR lime]Change Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
    common . addLink ( "[COLOR red]Disable Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
    if 24 - 24: i1iIIi1
 if I1I == 0 :
  common . addLink ( "[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR red]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  common . addLink ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
  if 56 - 56: I1
def o0O ( ) :
 if 72 - 72: iI / I1111 * oO0 - OO0O00
 I1i1I1II = plugintools . get_setting ( "history_setting" )
 if 51 - 51: o0o0Oo0oooo0 * IIIi1i1I % IiiIII111ii * o0o0Oo0oooo0 % i1iIIi1 / I1
 if I1i1I1II == "true" :
  common . addLink ( '[COLOR deeppink]Clear History[/COLOR]' , iI1Ii11111iIi , 104 , iiiii , O0O0OO0O0O0 )
  common . addLink ( '[COLOR red]Disable History[/COLOR]' , iI1Ii11111iIi , 106 , iiiii , O0O0OO0O0O0 )
  common . addLink ( '###########################################' , iI1Ii11111iIi , 999 , iiiii , O0O0OO0O0O0 )
  if 49 - 49: IiiIII111ii
  ii11iIi1I = open ( oOOoo00O0O , mode = 'r' ) ; iI111I11I1I1 = ii11iIi1I . read ( ) ; ii11iIi1I . close ( )
  iI111I11I1I1 = iI111I11I1I1 . replace ( '\n' , '' )
  IIii1Ii1 = re . compile ( '<item>(.+?)</item>' ) . findall ( iI111I11I1I1 )
  for I1II11IiII in IIii1Ii1 :
   OOO0OOo = re . compile ( '<date>(.+?)</date>' ) . findall ( I1II11IiII ) [ 0 ]
   time = re . compile ( '<time>(.+?)</time>' ) . findall ( I1II11IiII ) [ 0 ]
   I1I111 = re . compile ( '<name>(.+?)</name>' ) . findall ( I1II11IiII ) [ 0 ]
   Ooo0OO0oOO = re . compile ( '<link>(.+?)</link>' ) . findall ( I1II11IiII ) [ 0 ]
   i11iiI111I = re . compile ( '<site>(.+?)</site>' ) . findall ( I1II11IiII ) [ 0 ]
   II11i1iIiII1 = re . compile ( '<icon>(.+?)</icon>' ) . findall ( I1II11IiII ) [ 0 ]
   Ooo0OO0oOO = I1I111 + '|SPLIT|' + Ooo0OO0oOO + '|SPLIT|' + i11iiI111I + '|SPLIT|' + II11i1iIiII1 + '|SPLIT|' + Ooo0OO0oOO
   if 17 - 17: I11iii
   common . addLink ( '[COLOR pink]' + OOO0OOo + ' | ' + '[/COLOR][COLOR deeppink]' + time + '[/COLOR] - [COLOR red]' + i11iiI111I + '[/COLOR][COLOR pink] - ' + I1I111 + '[/COLOR]' , Ooo0OO0oOO , 800 , II11i1iIiII1 , O0O0OO0O0O0 )
 else : common . addLink ( '[COLOR red]Enable History Monitoring[/COLOR]' , iI1Ii11111iIi , 106 , iiiii , O0O0OO0O0O0 )
 if 62 - 62: I1iII1iiII * i11IiIiiIIIII
def i1OOO ( ) :
 if 59 - 59: o0o0Oo0oooo0 + oOOOO0o0o * i11IiIiiIIIII + I1111
 common . addLink ( '[COLOR deeppink]Your Favourites[/COLOR]' , iI1Ii11111iIi , 999 , iiiii , O0O0OO0O0O0 )
 common . addLink ( '###########################################' , iI1Ii11111iIi , 999 , iiiii , O0O0OO0O0O0 )
 if 58 - 58: o0o0Oo0oooo0 * IiI1I1 * i1iIIi1 / IiI1I1
 ii11iIi1I = open ( i1111 , mode = 'r' ) ; iI111I11I1I1 = ii11iIi1I . read ( ) ; ii11iIi1I . close ( )
 iI111I11I1I1 = iI111I11I1I1 . replace ( '\n' , '' )
 IIii1Ii1 = re . compile ( '<item>(.+?)</item>' ) . findall ( iI111I11I1I1 )
 for I1II11IiII in IIii1Ii1 :
  I1I111 = re . compile ( '<name>(.+?)</name>' ) . findall ( I1II11IiII ) [ 0 ]
  Ooo0OO0oOO = re . compile ( '<link>(.+?)</link>' ) . findall ( I1II11IiII ) [ 0 ]
  i11iiI111I = re . compile ( '<site>(.+?)</site>' ) . findall ( I1II11IiII ) [ 0 ]
  II11i1iIiII1 = re . compile ( '<icon>(.+?)</icon>' ) . findall ( I1II11IiII ) [ 0 ]
  Ooo0OO0oOO = I1I111 + '|SPLIT|' + Ooo0OO0oOO + '|SPLIT|' + i11iiI111I + '|SPLIT|' + II11i1iIiII1 + '|SPLIT|' + Ooo0OO0oOO
  common . addLink ( '[COLOR red]' + i11iiI111I + '[/COLOR][COLOR pink] - ' + I1I111 + '[/COLOR]' , Ooo0OO0oOO , 103 , II11i1iIiII1 , O0O0OO0O0O0 )
  if 75 - 75: o00o
def I1III ( name , url , iconimage ) :
 if 63 - 63: IiI1I1 % o00o * o00o * IIIi1i1I / i1iIIi1
 o0ooO = url
 O0o0O00Oo0o0 , O00O0oOO00O00 , i1Oo00 , i1i , url = url . split ( '|SPLIT|' )
 if 50 - 50: I11iii
 Iii111II = '\n<item>\n<name>' + O0o0O00Oo0o0 + '</name>\n<link>' + O00O0oOO00O00 + '</link>\n<site>' + i1Oo00 + '</site>\n<icon>' + i1i + '</icon>\n</item>\n'
 if 14 - 14: oOoO % IIIi1i1I * oOoO
 OOooO0OOoo = i1i1II . select ( "[COLOR red][B]Please select an option[/B][/COLOR]" , [ '[COLOR pink][B]Watch Video[/B][/COLOR]' , '[COLOR pink][B]Remove from Favourites[/B][/COLOR]' ] )
 if 16 - 16: i11IiIiiIIIII . I1 + i11iIiiIii
 if OOooO0OOoo == 0 :
  i1i1I1IIii1II ( name , o0ooO , iconimage )
 else :
  O0 = open ( i1111 ) . read ( )
  ii11iIi1I = O0 . replace ( Iii111II , '\n' )
  ii1ii1ii = open ( i1111 , mode = 'w' )
  ii1ii1ii . write ( str ( ii11iIi1I ) )
  ii1ii1ii . close ( )
  xbmc . executebuiltin ( "Container.Refresh" )
  quit ( )
  if 91 - 91: I11iii
def iiIii ( name , url , iconimage ) :
 if 79 - 79: oOOOO0o0o / O00ooOO
 o0ooO = url
 O0o0O00Oo0o0 , O00O0oOO00O00 , i1Oo00 , i1i , url = url . split ( '|SPLIT|' )
 if 75 - 75: i11IiIiiIIIII % IiiIII111ii % IiiIII111ii . OO0O00
 OOooO0OOoo = i1i1II . select ( "[COLOR red][B]Please select an option[/B][/COLOR]" , [ '[COLOR pink][B]Watch Video[/B][/COLOR]' , '[COLOR pink][B]Delete Download[/B][/COLOR]' ] )
 if 5 - 5: IiiIII111ii * I1 + i11IiIiiIIIII . IiI1I1 + i11IiIiiIIIII
 if OOooO0OOoo == 0 :
  i1i1I1IIii1II ( name , o0ooO , iconimage )
 else :
  os . remove ( url )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 91 - 91: O00ooOO
def oOOo0 ( ) :
 if 54 - 54: O00ooOO - I11iii % IiI1I1
 if os . path . isfile ( oOOoo00O0O ) :
  OOooO0OOoo = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]Would you like to clear all stored history?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[B][COLOR red]NO[/COLOR][/B]' )
  if OOooO0OOoo == 1 :
   os . remove ( oOOoo00O0O )
   ii11iIi1I = open ( oOOoo00O0O , 'w' )
   ii11iIi1I . write ( '#START OF FILE#' )
   ii11iIi1I . close ( )
 xbmc . executebuiltin ( "Container.Refresh" )
 if 77 - 77: i11IiIiiIIIII / I1I1i1 / IIIi1i1I + IIIi1i1I . IiI1I1
def ii1ii11IIIiiI ( ) :
 if 67 - 67: oOoO * o00o * i1iIIi1 + IiI1I1 / I1111
 oO00 = plugintools . get_setting ( "download_location" )
 I1I111Oo00oo0oO = xbmc . translatePath ( oO00 )
 common . addLink ( '[COLOR deeppink]Download Location: [/COLOR]' , iI1Ii11111iIi , 999 , iiiii , O0O0OO0O0O0 )
 common . addLink ( I1I111Oo00oo0oO , iI1Ii11111iIi , 999 , iiiii , O0O0OO0O0O0 )
 common . addLink ( '[COLOR red]Change Download Location[/COLOR]' , iI1Ii11111iIi , 106 , iiiii , O0O0OO0O0O0 )
 common . addLink ( '###########################################' , iI1Ii11111iIi , 999 , iiiii , O0O0OO0O0O0 )
 if 1 - 1: IIIi1i1I - o00o . oOoO . IIIi1i1I / oO0 + oOoO
 OooOOOOo = [ '.mp4' , '.avi' , '.mkv' ]
 if 76 - 76: IIIi1i1I
 for file in os . listdir ( I1I111Oo00oo0oO ) :
  for I1iIIii in OooOOOOo :
   if file . endswith ( I1iIIii ) :
    Ooo0OO0oOO = xbmc . translatePath ( os . path . join ( I1I111Oo00oo0oO , file ) )
    iii1i = file + '|SPLIT|' + Ooo0OO0oOO + '|SPLIT|Downloaded|SPLIT|None|SPLIT|' + Ooo0OO0oOO
    common . addLink ( '[COLOR pink]' + file + '[/COLOR]' , iii1i , 107 , iiiii , O0O0OO0O0O0 )
    if 39 - 39: iI - O00ooOO % i11iIiiIii * OO0O00 . I11iii
def OOooo0O00o ( ) :
 if 85 - 85: IiiIII111ii - oO0
 oO00 = plugintools . get_setting ( "download_location" )
 iiIiI = i1i1II . browse ( 3 , Oo0Ooo , 'files' , '' , False , False , Ii1iI )
 O0 = open ( i11 ) . read ( )
 ii11iIi1I = O0 . replace ( oO00 , iiIiI )
 ii1ii1ii = open ( i11 , mode = 'w' )
 ii1ii1ii . write ( str ( ii11iIi1I ) )
 ii1ii1ii . close ( )
 xbmc . executebuiltin ( "Container.Refresh" )
 if 91 - 91: iI % I1111 % I1iII1iiII
def IIi1I11I1II ( name , url , iconimage ) :
 if 63 - 63: oOOOO0o0o - IIIi1i1I . o0o0Oo0oooo0 / IiiIII111ii . i11IiIiiIIIII / O00ooOO
 O0o0O00Oo0o0 , O00O0oOO00O00 , i1Oo00 , i1i , url = url . split ( '|SPLIT|' )
 name = O0o0O00Oo0o0
 o0OOOO00O0Oo = datetime . datetime . now ( ) . strftime ( "%d-%m-%Y" )
 ii = datetime . datetime . now ( ) . strftime ( "%H:%M" )
 Iii111II = '\n<item>\n<date>' + o0OOOO00O0Oo + '</date>\n<time>' + ii + '</time>\n<name>' + O0o0O00Oo0o0 + '</name>\n<link>' + O00O0oOO00O00 + '</link>\n<site>' + i1Oo00 + '</site>\n<icon>' + i1i + '</icon>\n</item>\n'
 O0o0O00Oo0o0 = open ( oOOoo00O0O ) . read ( )
 O00O0oOO00O00 = O0o0O00Oo0o0 . replace ( '#START OF FILE#' , '#START OF FILE#' + Iii111II )
 ii11iIi1I = open ( oOOoo00O0O , mode = 'w' )
 ii11iIi1I . write ( str ( O00O0oOO00O00 ) )
 ii11iIi1I . close ( )
 if 90 - 90: IiiIII111ii % I1111 / IIIi1i1I
 if iconimage == "None" :
  iconimage = iiiii
 IIi = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , IIi , False )
 if 41 - 41: iiIiIIi - O00ooOO - O00ooOO
def i1i1I1IIii1II ( name , url , iconimage ) :
 if 68 - 68: IiI1I1 % OO0O00
 O0o0O00Oo0o0 , O00O0oOO00O00 , i1Oo00 , i1i , url = url . split ( '|SPLIT|' )
 name = O0o0O00Oo0o0
 o0OOOO00O0Oo = datetime . datetime . now ( ) . strftime ( "%d-%m-%Y" )
 ii = datetime . datetime . now ( ) . strftime ( "%H:%M" )
 Iii111II = '\n<item>\n<date>' + o0OOOO00O0Oo + '</date>\n<time>' + ii + '</time>\n<name>' + O0o0O00Oo0o0 + '</name>\n<link>' + O00O0oOO00O00 + '</link>\n<site>' + i1Oo00 + '</site>\n<icon>' + i1i + '</icon>\n</item>\n'
 O0o0O00Oo0o0 = open ( oOOoo00O0O ) . read ( )
 O00O0oOO00O00 = O0o0O00Oo0o0 . replace ( '#START OF FILE#' , '#START OF FILE#' + Iii111II )
 ii11iIi1I = open ( oOOoo00O0O , mode = 'w' )
 ii11iIi1I . write ( str ( O00O0oOO00O00 ) )
 ii11iIi1I . close ( )
 if 88 - 88: I1iII1iiII - I1 + IiI1I1
 if iconimage == "None" :
  iconimage = iiiii
 IIi = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , IIi , False )
 if 40 - 40: I1I1i1 * iiIiIIi + IiI1I1 % iI
def OoO000 ( ) :
 if 74 - 74: o00o - oO0 + oOOOO0o0o + OO0O00 / i11IiIiiIIIII
 ii1 = common . _get_keyboard ( heading = "Please Set Password" )
 if ( not ii1 ) :
  i1i1II . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 o0oO0o00oo = ii1
 if 23 - 23: O00ooOO
 ii1 = common . _get_keyboard ( heading = "Please Confirm Your Password" )
 if ( not ii1 ) :
  i1i1II . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 o00oO0oOo00 = ii1
 if 81 - 81: IIIi1i1I
 if not os . path . exists ( OoI1Ii11I1Ii1i ) :
  if not os . path . exists ( i1 ) :
   os . makedirs ( i1 )
  open ( OoI1Ii11I1Ii1i , 'w' )
  if 42 - 42: IIIi1i1I / oOoO / IiiIII111ii + iI / i11IiIiiIIIII
  if o0oO0o00oo == o00oO0oOo00 :
   o0OoOO000ooO0 = base64 . b64encode ( o0oO0o00oo )
   ii11iIi1I = open ( OoI1Ii11I1Ii1i , 'w' )
   ii11iIi1I . write ( '<password>' + str ( o0OoOO000ooO0 ) + '</password>' )
   ii11iIi1I . close ( )
   i1i1II . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   i1i1II . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
 else :
  os . remove ( OoI1Ii11I1Ii1i )
  if 56 - 56: iI
  if o0oO0o00oo == o00oO0oOo00 :
   o0OoOO000ooO0 = base64 . b64encode ( o0oO0o00oo )
   ii11iIi1I = open ( OoI1Ii11I1Ii1i , 'w' )
   ii11iIi1I . write ( '<password>' + str ( o0OoOO000ooO0 ) + '</password>' )
   ii11iIi1I . close ( )
   i1i1II . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   i1i1II . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
   if 86 - 86: o0o0Oo0oooo0 % OO0O00
def iiIIiiIi1Ii11 ( ) :
 if 65 - 65: o0o0Oo0oooo0 . IiI1I1 % oOoO . i11iIiiIii + O00ooOO
 try :
  os . remove ( OoI1Ii11I1Ii1i )
  i1i1II . ok ( Oo0Ooo , 'Parental controls have been disabled.' )
  xbmc . executebuiltin ( "Container.Refresh" )
 except :
  i1i1II . ok ( Oo0Ooo , 'There was an error disabling the parental controls.' )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 26 - 26: oOoO - I1iII1iiII - I1I1i1 / IIIi1i1I . i11IiIiiIIIII % I1iII1iiII
def OO ( ) :
 iIiIIi1 = [ ]
 I1IIII1i = sys . argv [ 2 ]
 if len ( I1IIII1i ) >= 2 :
  I1I11i = sys . argv [ 2 ]
  Ii1I1I1i1Ii = I1I11i . replace ( '?' , '' )
  if ( I1I11i [ len ( I1I11i ) - 1 ] == '/' ) :
   I1I11i = I1I11i [ 0 : len ( I1I11i ) - 2 ]
  i1Oo0oO00o = Ii1I1I1i1Ii . split ( '&' )
  iIiIIi1 = { }
  for i11I1II1I11i in range ( len ( i1Oo0oO00o ) ) :
   OooOoOO0 = { }
   OooOoOO0 = i1Oo0oO00o [ i11I1II1I11i ] . split ( '=' )
   if ( len ( OooOoOO0 ) ) == 2 :
    iIiIIi1 [ OooOoOO0 [ 0 ] ] = OooOoOO0 [ 1 ]
    if 36 - 36: I11iii
 return iIiIIi1
 if 36 - 36: I1 / O00ooOO * oO0 - IiI1I1 % I1iII1iiII * o00o
I1I11i = OO ( ) ; o0 = None ; Ooo0OO0oOO = None ; iI11I1II = None ; II11i1iIiII1 = None ; Ii1I = None
try : o0 = urllib . unquote_plus ( I1I11i [ "name" ] )
except : pass
try : Ooo0OO0oOO = urllib . unquote_plus ( I1I11i [ "url" ] )
except : pass
try : iI11I1II = int ( I1I11i [ "mode" ] )
except : pass
try : II11i1iIiII1 = urllib . unquote_plus ( I1I11i [ "iconimage" ] )
except : pass
try : Ii1I = urllib . quote_plus ( I1I11i [ "fanartimage" ] )
except : pass
if 39 - 39: o0o0Oo0oooo0 / I1 + OO0O00 / i11IiIiiIIIII
if iI11I1II == None or Ooo0OO0oOO == None or len ( Ooo0OO0oOO ) < 1 : OOoOoo00oo ( )
if 13 - 13: I11iii + O00ooOO + iI % I1I1i1 / IiiIII111ii . I11iii
elif iI11I1II == 10 : xhamster . MAIN_MENU ( )
elif iI11I1II == 11 : xhamster . GET_CONTENT ( Ooo0OO0oOO )
elif iI11I1II == 12 : xhamster . SEARCH ( )
elif iI11I1II == 13 : xhamster . PLAY_URL ( o0 , Ooo0OO0oOO , II11i1iIiII1 )
elif iI11I1II == 20 : chaturbate . MAIN_MENU ( )
elif iI11I1II == 21 : chaturbate . GET_CONTENT ( Ooo0OO0oOO )
elif iI11I1II == 22 : chaturbate . SEARCH ( )
elif iI11I1II == 23 : chaturbate . PLAY_URL ( o0 , Ooo0OO0oOO , II11i1iIiII1 )
elif iI11I1II == 30 : xnxx . MAIN_MENU ( )
elif iI11I1II == 31 : xnxx . GET_CONTENT ( Ooo0OO0oOO )
elif iI11I1II == 32 : xnxx . SEARCH ( )
elif iI11I1II == 33 : xnxx . PLAY_URL ( o0 , Ooo0OO0oOO , II11i1iIiII1 )
elif iI11I1II == 34 : xnxx . PICTURE_MENU ( )
elif iI11I1II == 35 : xnxx . PICTURE_CONTENT ( Ooo0OO0oOO )
elif iI11I1II == 36 : xnxx . SCRAPE_GALLERY ( Ooo0OO0oOO )
elif iI11I1II == 37 : xnxx . DISPLAY_PICTURE ( Ooo0OO0oOO )
elif iI11I1II == 38 : xnxx . STORY_MENU ( )
elif iI11I1II == 39 : xnxx . LIST_STORIES ( Ooo0OO0oOO )
elif iI11I1II == 40 : xnxx . DISPLAY_STORY ( Ooo0OO0oOO )
elif iI11I1II == 41 : redtube . MAIN_MENU ( )
elif iI11I1II == 42 : redtube . GET_CONTENT ( Ooo0OO0oOO )
elif iI11I1II == 43 : redtube . SEARCH ( )
elif iI11I1II == 44 : redtube . PLAY_URL ( o0 , Ooo0OO0oOO , II11i1iIiII1 )
elif iI11I1II == 50 : pornhd . MAIN_MENU ( )
elif iI11I1II == 51 : pornhd . GET_CONTENT ( Ooo0OO0oOO )
elif iI11I1II == 52 : pornhd . SEARCH ( )
elif iI11I1II == 53 : pornhd . PLAY_URL ( o0 , Ooo0OO0oOO , II11i1iIiII1 )
elif iI11I1II == 60 : porncom . MAIN_MENU ( )
elif iI11I1II == 61 : porncom . GET_CONTENT ( Ooo0OO0oOO )
elif iI11I1II == 62 : porncom . SEARCH ( )
elif iI11I1II == 63 : porncom . PLAY_URL ( o0 , Ooo0OO0oOO , II11i1iIiII1 )
elif iI11I1II == 70 : youporn . MAIN_MENU ( )
elif iI11I1II == 71 : youporn . GET_CONTENT ( Ooo0OO0oOO )
elif iI11I1II == 72 : youporn . SEARCH ( )
elif iI11I1II == 73 : youporn . PLAY_URL ( o0 , Ooo0OO0oOO , II11i1iIiII1 )
elif iI11I1II == 100 : iIii11I ( )
elif iI11I1II == 101 : o0O ( )
elif iI11I1II == 102 : i1OOO ( )
elif iI11I1II == 103 : I1III ( o0 , Ooo0OO0oOO , II11i1iIiII1 )
elif iI11I1II == 104 : oOOo0 ( )
elif iI11I1II == 105 : ii1ii11IIIiiI ( )
elif iI11I1II == 106 : plugintools . open_settings_dialog ( ) ; xbmc . executebuiltin ( 'Container.Refresh' )
elif iI11I1II == 107 : iiIii ( o0 , Ooo0OO0oOO , II11i1iIiII1 )
elif iI11I1II == 800 : i1i1I1IIii1II ( o0 , Ooo0OO0oOO , II11i1iIiII1 )
elif iI11I1II == 900 : Ii1i11IIii1I ( )
elif iI11I1II == 901 : OoO000 ( )
elif iI11I1II == 902 : iiIIiiIi1Ii11 ( )
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3