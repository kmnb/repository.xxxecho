import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , shutil
import base64 , time , datetime
from resources . lib . modules import plugintools
from resources . lib . modules import menus
from resources . lib . modules import common
from resources . lib . modules import checker
from resources . lib . modules import cache
from resources . lib . modules import downloader
from resources . lib . modules import extract
from resources . lib . scrapers import chaturbate
from resources . lib . scrapers import xnxx
from resources . lib . scrapers import youporn
from resources . lib . scrapers import porncom
from resources . lib . scrapers import pornhd
from resources . lib . scrapers import redtube
from resources . lib . scrapers import xhamster
from resources . lib . scrapers import pornfun
from resources . lib . scrapers import motherless
from resources . lib . scrapers import spankbang
from resources . lib . scrapers import porn00
from resources . lib . scrapers import virtualpornstars
from resources . lib . scrapers import watchxxxfree
from resources . lib . scrapers import perfectgirls
from resources . lib . scrapers import justpornotv
from resources . lib . scrapers import eporner
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.xxx-o-dus'
Oo0Ooo = '[COLOR orangered]XXX-O-DUS[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/xhamster/icon.png' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/xhamster/fanart.jpg' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/chaturbate/icon.png' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/chaturbate/fanart.jpg' ) )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/xnxx/icon.png' ) )
I11i11Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/xnxx/fanart.jpg' ) )
oO00oOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/redtube/icon.png' ) )
OOOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/redtube/fanart.jpg' ) )
Oooo000o = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/pornhd/icon.png' ) )
IiIi11iIIi1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/pornhd/fanart.jpg' ) )
Oo0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/porncom/icon.png' ) )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/porncom/fanart.jpg' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/youporn/icon.png' ) )
Oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/youporn/fanart.jpg' ) )
o0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/pornfun/icon.png' ) )
IiiIII111iI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/pornfun/fanart.jpg' ) )
IiII = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/spankbang/icon.png' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/spankbang/fanart.jpg' ) )
i1i1II = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/watchxxxfree/icon.png' ) )
O0oo0OO0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/watchxxxfree/fanart.jpg' ) )
I1i1iiI1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/justporno/icon.png' ) )
iiIIIII1i1iI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/justporno/fanart.jpg' ) )
if 68 - 68: o00ooo0 / Oo00O0
ooO0oooOoO0 = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
II11i = xbmcgui . Dialog ( )
i1 = xbmcgui . DialogProgress ( )
if 64 - 64: oo % O0Oooo00
Ooo0 = xbmc . translatePath ( 'special://home/' )
oo00000o0 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'settings.xml' ) )
I11i1i11i1I = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'parental' ) )
Iiii = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o ) )
OOO0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o ) )
oo0ooO0oOOOOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
oO000OoOoo00o = xbmc . translatePath ( os . path . join ( I11i1i11i1I , 'controls.txt' ) )
iiiI11 = xbmc . translatePath ( os . path . join ( OOO0O , 'resources/disclaimer.txt' ) )
OOooO = xbmc . translatePath ( os . path . join ( OOO0O , 'resources/information.txt' ) )
OOoO00o = xbmc . translatePath ( os . path . join ( OOO0O , 'resources/repository.txt' ) )
II111iiii = xbmc . translatePath ( os . path . join ( OOO0O , 'resources/reset.txt' ) )
II = xbmc . translatePath ( os . path . join ( Iiii , 'agreed.txt' ) )
oOoOo00oOo = xbmc . translatePath ( os . path . join ( Iiii , 'history.xml' ) )
Ooo00O00O0O0O = xbmc . translatePath ( os . path . join ( Iiii , 'favourites.xml' ) )
OooO0OO = xbmc . translatePath ( os . path . join ( Iiii , 'downloads.xml' ) )
iiiIi = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.xxxecho' ) )
if 24 - 24: iIiI1I11 % i111I1 % oOoO - iiIiIIi % ooOoo0O
OooO0 = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
II11iiii1Ii = xbmc . translatePath ( 'special://home/addons/repository.xxxecho/addon.xml' )
OO0oOoo = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS54eHhlY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8ueHh4LW8tZHVzL3BsdWdpbi52aWRlby54eHgtby1kdXMt' )
O0o0Oo = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS54eHhlY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5Lnh4eGVjaG8vcmVwb3NpdG9yeS54eHhlY2hvLQ==' )
if 78 - 78: IIIIII11i1I - o0o0OOO0o0 % IIII % o0O0 . ii1I11II1ii1i % oO0o0ooo
cache . check ( )
if 20 - 20: OoO0
def Ooooo ( ) :
 if 2 - 2: Oo0O0OOOoo / IiIiiI * oO0oOOO00oO / IIII
 OoOo = iiiIi + '|SPLIT|' + OOoO00o
 checker . check ( OoOo )
 if 18 - 18: i11iIiiIii
 if not os . path . exists ( II ) :
  Ii11I = open ( iiiI11 , mode = 'r' ) ; OOO0OOO00oo = Ii11I . read ( ) ; Ii11I . close ( )
  common . TextBoxes ( "%s" % OOO0OOO00oo )
  Iii111II = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]Do you agree to the terms and conditions of this addon?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[COLOR orangered]NO[/COLOR]' )
  if Iii111II == 1 :
   Ii11I = open ( OOooO , mode = 'r' ) ; OOO0OOO00oo = Ii11I . read ( ) ; Ii11I . close ( )
   common . TextBoxes ( "%s" % OOO0OOO00oo )
   II11i . ok ( Oo0Ooo , "[COLOR pink]We can see this is the first time you have used XXX-O-DUS. The next prompt is important as it will allow you to enable the history section of the addon and it will also allow you to select the location you would like to be used to download videos.[/COLOR]" )
   plugintools . open_settings_dialog ( )
   open ( II , 'w' )
  else :
   sys . exit ( 0 )
   if 9 - 9: iiIiIIi
 if not os . path . exists ( I11i1i11i1I ) :
  Iii111II = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , "[COLOR white]Would you like to enable the parental controls now?[/COLOR]" , "" , yeslabel = '[COLOR orangered]NO[/COLOR]' , nolabel = '[COLOR lime]YES[/COLOR]' )
  if Iii111II == 0 :
   i11 ( )
  else :
   os . makedirs ( I11i1i11i1I )
   if 58 - 58: o0O0 * i11iIiiIii / ooOoo0O % IiIiiI - o0o0OOO0o0 / IIII
 elif os . path . exists ( oO000OoOoo00o ) :
  ii11i1 = common . _get_keyboard ( heading = "Please Enter Your Password" )
  if ( not ii11i1 ) :
   II11i . ok ( Oo0Ooo , "Sorry, no password was entered." )
   sys . exit ( 0 )
  IIIii1II1II = ii11i1
  if 42 - 42: oO0o0ooo + IIII
  o0O0o0Oo = open ( oO000OoOoo00o , "r" )
  Ii11Ii1I = re . compile ( r'<password>(.+?)</password>' )
  for O00oO in o0O0o0Oo :
   file = Ii11Ii1I . findall ( O00oO )
   for I11i1I1I in file :
    oO0Oo = base64 . b64decode ( I11i1I1I )
    if not oO0Oo == IIIii1II1II :
     if not I11i1I1I == IIIii1II1II :
      II11i . ok ( Oo0Ooo , "Sorry, the password you entered was incorrect." )
      sys . exit ( 0 )
      if 54 - 54: IIIIII11i1I - i111I1 + oo
 O0o0 = plugintools . get_setting ( "download_location" )
 OO00Oo = xbmc . translatePath ( O0o0 )
 if not os . path . exists ( OO00Oo ) :
  os . makedirs ( OO00Oo )
  if 51 - 51: Oo0O0OOOoo * IIIIII11i1I + ii1I11II1ii1i + iiIiIIi
 if not os . path . isfile ( oOoOo00oOo ) :
  Ii11I = open ( oOoOo00oOo , 'w' )
  Ii11I . write ( '#START OF FILE#' )
  Ii11I . close ( )
 if not os . path . isfile ( Ooo00O00O0O0O ) :
  Ii11I = open ( Ooo00O00O0O0O , 'w' )
  Ii11I . write ( '#START OF FILE#' )
  Ii11I . close ( )
 if not os . path . isfile ( OooO0OO ) :
  Ii11I = open ( OooO0OO , 'w' )
  Ii11I . write ( '#START OF FILE#' )
  Ii11I . close ( )
  if 66 - 66: ooOoo0O
 oO000Oo000 = open ( OooO0 ) . read ( )
 i111IiI1I = oO000Oo000 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 O0 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( i111IiI1I ) )
 for iII in O0 :
  o0 = float ( iII )
 oO000Oo000 = open ( II11iiii1Ii ) . read ( )
 i111IiI1I = oO000Oo000 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 O0 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( i111IiI1I ) )
 for iII in O0 :
  ooOooo000oOO = float ( iII )
  if 59 - 59: iIiI1I11 + oo * ooOoo0O + O0Oooo00
 common . addDir ( "[COLOR white]SEARCH XXX-O-DUS[/COLOR]" , "url" , 1 , iiiii , O0O0OO0O0O0 )
 common . addDir ( "[COLOR white]Live[/COLOR]" , "url" , 3 , iiiii , O0O0OO0O0O0 )
 common . addDir ( "[COLOR white]Videos[/COLOR]" , "url" , 2 , iiiii , O0O0OO0O0O0 )
 common . addDir ( "[COLOR white]Photos[/COLOR]" , "url" , 4 , iiiii , O0O0OO0O0O0 )
 common . addDir ( "[COLOR white]Stories[/COLOR]" , "url" , 5 , iiiii , O0O0OO0O0O0 )
 common . addLink ( "[COLOR darkgray]#################################[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
 common . addDir ( "[COLOR deeppink]Your History[/COLOR]" , ooO0oooOoO0 , 101 , iiiii , O0O0OO0O0O0 )
 common . addDir ( "[COLOR deeppink]Your Favourites[/COLOR]" , ooO0oooOoO0 , 102 , iiiii , O0O0OO0O0O0 )
 common . addDir ( "[COLOR deeppink]Your Downloads[/COLOR]" , ooO0oooOoO0 , 105 , iiiii , O0O0OO0O0O0 )
 common . addLink ( "[COLOR deeppink]Your Settings[/COLOR]" , ooO0oooOoO0 , 106 , iiiii , O0O0OO0O0O0 )
 if 58 - 58: iIiI1I11 * o0O0 * o0o0OOO0o0 / o0O0
 if not os . path . exists ( oO000OoOoo00o ) :
  common . addDir ( "[COLOR orangered]PARENTAL CONTROLS - [COLOR orangered]OFF[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
 else :
  common . addDir ( "[COLOR orangered]PARENTAL CONTROLS - [COLOR lime]ON[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
 common . addLink ( "[COLOR white]#####################################[/COLOR]" , ooO0oooOoO0 , 999 , iiiii , O0O0OO0O0O0 )
 common . addLink ( "[COLOR pink]Twitter Support: [/COLOR][COLOR white]@EchoCoder[/COLOR]" , ooO0oooOoO0 , 999 , iiiii , O0O0OO0O0O0 )
 common . addLink ( "[COLOR white]View Disclaimer[/COLOR]" , iiiI11 , 998 , iiiii , O0O0OO0O0O0 )
 common . addLink ( "[COLOR white]View Addon Information[/COLOR]" , OOooO , 998 , iiiii , O0O0OO0O0O0 )
 common . addLink ( "[COLOR orangered]RESET XXX-O-DUS[/COLOR]" , 'url' , 997 , iiiii , O0O0OO0O0O0 )
 common . addLink ( "[COLOR deeppink]Addon Version:[/COLOR] [COLOR white]" + str ( o0 ) + "[/COLOR]" , 'url' , 999 , iiiii , O0O0OO0O0O0 )
 common . addLink ( "[COLOR deeppink]Repository Version:[/COLOR] [COLOR white]" + str ( ooOooo000oOO ) + "[/COLOR]" , 'url' , 999 , iiiii , O0O0OO0O0O0 )
 if 75 - 75: IIII
 I1III = common . GET_KODI_VERSION ( )
 if 63 - 63: o0O0 % IIII * IIII * iiIiIIi / o0o0OOO0o0
 if I1III == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif I1III == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 74 - 74: iIiI1I11
def oO0 ( ) :
 if 54 - 54: iIiI1I11 % ooOoo0O % ii1I11II1ii1i % Oo00O0 + Oo00O0 * oO0oOOO00oO
 O00O0oOO00O00 = 15
 i1Oo00 = 0
 i1i = ''
 iiI111I1iIiI = xbmc . Keyboard ( i1i , 'Enter Search Term' )
 iiI111I1iIiI . doModal ( )
 if iiI111I1iIiI . isConfirmed ( ) :
  IIIi1I1IIii1II = iiI111I1iIiI . getText ( )
  O0ii1ii1ii = IIIi1I1IIii1II
  i1i = IIIi1I1IIii1II . replace ( ' ' , '+' )
  if len ( i1i ) > 1 :
   try :
    i1Oo00 = i1Oo00 + 1
    oooooOoo0ooo = 100 * int ( i1Oo00 ) / int ( O00O0oOO00O00 )
    i1 . create ( Oo0Ooo , '[COLOR white]Searching: [/COLOR] [COLOR orangered]YouPorn[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0ii1ii1ii . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]' + str ( i1Oo00 ) + ' of ' + str ( O00O0oOO00O00 ) + '[/COLOR]' )
    I1I1IiI1 = "http://www.youporn.com/search/?query=" + i1i . lower ( )
    I1I1IiI1 = 'split|' + I1I1IiI1
    i1 . update ( oooooOoo0ooo )
    try :
     youporn . GET_CONTENT ( I1I1IiI1 )
    except : pass
    I1I1IiI1 = "http://www.xnxx.com/?k=" + i1i . lower ( )
    I1I1IiI1 = 'split|' + I1I1IiI1
    i1Oo00 = i1Oo00 + 1
    oooooOoo0ooo = 100 * int ( i1Oo00 ) / int ( O00O0oOO00O00 )
    i1 . update ( oooooOoo0ooo , '[COLOR white]Searching: [/COLOR] [COLOR orangered]XNXX[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0ii1ii1ii . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]' + str ( i1Oo00 ) + ' of ' + str ( O00O0oOO00O00 ) + '[/COLOR]' )
    try :
     xnxx . GET_CONTENT ( I1I1IiI1 )
    except : pass
    I1I1IiI1 = "https://xhamster.com/search.php?from=&new=&q=" + i1i . lower ( ) + "&qcat=video"
    I1I1IiI1 = 'split|' + I1I1IiI1
    i1Oo00 = i1Oo00 + 1
    oooooOoo0ooo = 100 * int ( i1Oo00 ) / int ( O00O0oOO00O00 )
    i1 . update ( oooooOoo0ooo , '[COLOR white]Searching: [/COLOR] [COLOR orangered]Xhamster[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0ii1ii1ii . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]' + str ( i1Oo00 ) + ' of ' + str ( O00O0oOO00O00 ) + '[/COLOR]' )
    try :
     xhamster . GET_CONTENT ( I1I1IiI1 )
    except : pass
    I1I1IiI1 = "http://www.pornhd.com/search?search=" + i1i . lower ( )
    I1I1IiI1 = 'split|' + I1I1IiI1
    i1Oo00 = i1Oo00 + 1
    oooooOoo0ooo = 100 * int ( i1Oo00 ) / int ( O00O0oOO00O00 )
    i1 . update ( oooooOoo0ooo , '[COLOR white]Searching: [/COLOR] [COLOR orangered]PornHD[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0ii1ii1ii . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]' + str ( i1Oo00 ) + ' of ' + str ( O00O0oOO00O00 ) + '[/COLOR]' )
    try :
     pornhd . GET_CONTENT ( I1I1IiI1 )
    except : pass
    I1I1IiI1 = "http://www.porn.com/videos/search?q=" + i1i . lower ( )
    I1I1IiI1 = 'split|' + I1I1IiI1
    i1Oo00 = i1Oo00 + 1
    oooooOoo0ooo = 100 * int ( i1Oo00 ) / int ( O00O0oOO00O00 )
    i1 . update ( oooooOoo0ooo , '[COLOR white]Searching: [/COLOR] [COLOR orangered]Porn.com[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0ii1ii1ii . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]' + str ( i1Oo00 ) + ' of ' + str ( O00O0oOO00O00 ) + '[/COLOR]' )
    try :
     porncom . GET_CONTENT ( I1I1IiI1 )
    except : pass
    I1I1IiI1 = "http://www.redtube.com/?search=" + i1i . lower ( )
    I1I1IiI1 = 'split|' + I1I1IiI1
    i1Oo00 = i1Oo00 + 1
    oooooOoo0ooo = 100 * int ( i1Oo00 ) / int ( O00O0oOO00O00 )
    i1 . update ( oooooOoo0ooo , '[COLOR white]Searching: [/COLOR] [COLOR orangered]RedTube[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0ii1ii1ii . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]' + str ( i1Oo00 ) + ' of ' + str ( O00O0oOO00O00 ) + '[/COLOR]' )
    try :
     redtube . GET_CONTENT ( I1I1IiI1 )
    except : pass
    I1I1IiI1 = "http://pornfun.com/search/?q=" + i1i . lower ( )
    I1I1IiI1 = 'split|' + I1I1IiI1
    i1Oo00 = i1Oo00 + 1
    oooooOoo0ooo = 100 * int ( i1Oo00 ) / int ( O00O0oOO00O00 )
    i1 . update ( oooooOoo0ooo , '[COLOR white]Searching: [/COLOR] [COLOR orangered]PornFun[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0ii1ii1ii . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]' + str ( i1Oo00 ) + ' of ' + str ( O00O0oOO00O00 ) + '[/COLOR]' )
    try :
     pornfun . GET_CONTENT ( I1I1IiI1 )
    except : pass
    I1I1IiI1 = "http://spankbang.com/s/" + i1i . lower ( )
    I1I1IiI1 = 'split|' + I1I1IiI1
    i1Oo00 = i1Oo00 + 1
    oooooOoo0ooo = 100 * int ( i1Oo00 ) / int ( O00O0oOO00O00 )
    i1 . update ( oooooOoo0ooo , '[COLOR white]Searching: [/COLOR] [COLOR orangered]Spankbang[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0ii1ii1ii . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]' + str ( i1Oo00 ) + ' of ' + str ( O00O0oOO00O00 ) + '[/COLOR]' )
    try :
     spankbang . GET_CONTENT ( I1I1IiI1 )
    except : pass
    I1I1IiI1 = "http://www.porn00.org/?s=" + i1i . lower ( )
    I1I1IiI1 = 'split|' + I1I1IiI1
    i1Oo00 = i1Oo00 + 1
    oooooOoo0ooo = 100 * int ( i1Oo00 ) / int ( O00O0oOO00O00 )
    i1 . update ( oooooOoo0ooo , '[COLOR white]Searching: [/COLOR] [COLOR orangered]Porn00[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0ii1ii1ii . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]' + str ( i1Oo00 ) + ' of ' + str ( O00O0oOO00O00 ) + '[/COLOR]' )
    try :
     porn00 . GET_CONTENT ( 'none' , I1I1IiI1 , 'none' )
    except : pass
    I1I1IiI1 = "http://virtualpornstars.com/?s=" + i1i . lower ( )
    I1I1IiI1 = 'split|' + I1I1IiI1
    i1Oo00 = i1Oo00 + 1
    oooooOoo0ooo = 100 * int ( i1Oo00 ) / int ( O00O0oOO00O00 )
    i1 . update ( oooooOoo0ooo , '[COLOR white]Searching: [/COLOR] [COLOR orangered]Virtual Porn Stars[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0ii1ii1ii . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]' + str ( i1Oo00 ) + ' of ' + str ( O00O0oOO00O00 ) + '[/COLOR]' )
    try :
     virtualpornstars . GET_CONTENT ( I1I1IiI1 )
    except : pass
    I1I1IiI1 = "http://watchxxxfree.com/?s=" + i1i . lower ( )
    I1I1IiI1 = 'split|' + I1I1IiI1
    i1Oo00 = i1Oo00 + 1
    oooooOoo0ooo = 100 * int ( i1Oo00 ) / int ( O00O0oOO00O00 )
    i1 . update ( oooooOoo0ooo , '[COLOR white]Searching: [/COLOR] [COLOR orangered]Watch XXX Free[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0ii1ii1ii . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]' + str ( i1Oo00 ) + ' of ' + str ( O00O0oOO00O00 ) + '[/COLOR]' )
    try :
     watchxxxfree . GET_CONTENT ( I1I1IiI1 )
    except : pass
    i1i = i1i . replace ( '+' , '%20' )
    I1I1IiI1 = "http://www.perfectgirls.net/search/" + i1i . lower ( ) + '/'
    I1I1IiI1 = 'split|' + I1I1IiI1
    i1Oo00 = i1Oo00 + 1
    oooooOoo0ooo = 100 * int ( i1Oo00 ) / int ( O00O0oOO00O00 )
    i1 . update ( oooooOoo0ooo , '[COLOR white]Searching: [/COLOR] [COLOR orangered]Perfect Girls[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0ii1ii1ii . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]' + str ( i1Oo00 ) + ' of ' + str ( O00O0oOO00O00 ) + '[/COLOR]' )
    try :
     perfectgirls . GET_CONTENT ( I1I1IiI1 )
    except : pass
    i1i = i1i . replace ( '+' , '%20' )
    I1I1IiI1 = "http://motherless.com/term/" + i1i . lower ( )
    I1I1IiI1 = 'split|' + I1I1IiI1
    i1Oo00 = i1Oo00 + 1
    oooooOoo0ooo = 100 * int ( i1Oo00 ) / int ( O00O0oOO00O00 )
    i1 . update ( oooooOoo0ooo , '[COLOR white]Searching: [/COLOR] [COLOR orangered]Motherless[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0ii1ii1ii . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]' + str ( i1Oo00 ) + ' of ' + str ( O00O0oOO00O00 ) + '[/COLOR]' )
    try :
     motherless . GET_CONTENT ( I1I1IiI1 )
    except : pass
    i1i = i1i . replace ( '+' , '%20' )
    I1I1IiI1 = "http://justporno.tv/search?query=" + i1i . lower ( )
    I1I1IiI1 = 'split|' + I1I1IiI1
    i1Oo00 = i1Oo00 + 1
    oooooOoo0ooo = 100 * int ( i1Oo00 ) / int ( O00O0oOO00O00 )
    i1 . update ( oooooOoo0ooo , '[COLOR white]Searching: [/COLOR] [COLOR orangered]Just Porno TV[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0ii1ii1ii . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]' + str ( i1Oo00 ) + ' of ' + str ( O00O0oOO00O00 ) + '[/COLOR]' )
    try :
     justporno . GET_CONTENT ( I1I1IiI1 )
    except : pass
    i1i = i1i . replace ( '+' , '-' )
    I1I1IiI1 = "https://www.eporner.com/search/" + i1i . lower ( )
    I1I1IiI1 = 'split|' + I1I1IiI1
    i1Oo00 = i1Oo00 + 1
    oooooOoo0ooo = 100 * int ( i1Oo00 ) / int ( O00O0oOO00O00 )
    i1 . update ( oooooOoo0ooo , '[COLOR white]Searching: [/COLOR] [COLOR orangered]Eporner[/COLOR]' , '[COLOR white]Term: [/COLOR][COLOR deeppink]' + O0ii1ii1ii . lower ( ) + '[/COLOR]' , '[COLOR white]Source: [/COLOR][COLOR pink]' + str ( i1Oo00 ) + ' of ' + str ( O00O0oOO00O00 ) + '[/COLOR]' )
    try :
     eporner . GET_CONTENT ( I1I1IiI1 )
    except : pass
    i1 . close ( )
   except :
    II11i . ok ( Oo0Ooo , '[COLOR pink]Sorry, there was an error searching for ' + i1i . lower ( ) + ' please try again later.[/COLOR]' )
    quit ( )
  else : quit ( )
  if 5 - 5: IIIIII11i1I * oO0oOOO00oO + ooOoo0O . o0O0 + ooOoo0O
 I1III = common . GET_KODI_VERSION ( )
 if 91 - 91: o00ooo0
 if I1III == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 elif I1III == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 61 - 61: iIiI1I11
def O0OOO ( ) :
 if 10 - 10: o0O0 * ii1I11II1ii1i % ooOoo0O / i111I1 / ooOoo0O
 iIIi1i1 = 0
 if not os . path . exists ( oO000OoOoo00o ) :
  iIIi1i1 = 1
  common . addLink ( "[COLOR deeppink]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  common . addLink ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
 else :
  o0O0o0Oo = open ( oO000OoOoo00o , "r" )
  Ii11Ii1I = re . compile ( r'<password>(.+?)</password>' )
  for O00oO in o0O0o0Oo :
   file = Ii11Ii1I . findall ( O00oO )
   for I11i1I1I in file :
    oO0Oo = base64 . b64decode ( I11i1I1I )
    iIIi1i1 = 1
    common . addLink ( "[COLOR deeppink]PARENTAL CONTROLS - [/COLOR][COLOR lime]ON[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    common . addLink ( "[COLOR white]Current Password - [/COLOR][COLOR orangered]" + str ( oO0Oo ) + "[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    common . addLink ( "[COLOR lime]Change Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
    common . addLink ( "[COLOR orangered]Disable Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
    if 10 - 10: ii1I11II1ii1i
 if iIIi1i1 == 0 :
  common . addLink ( "[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  common . addLink ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
  if 82 - 82: o0o0OOO0o0 - Oo00O0 / o0O0 + oO0o0ooo
def OOOOoOoo0O0O0 ( ) :
 if 85 - 85: IIII % i11iIiiIii - OoO0 * oo / i111I1 % i111I1
 IIiIi1iI = plugintools . get_setting ( "history_setting" )
 if 35 - 35: oO0o0ooo % o00ooo0 - o00ooo0
 if IIiIi1iI == "true" :
  common . addLink ( '[COLOR deeppink]Clear History[/COLOR]' , ooO0oooOoO0 , 104 , iiiii , O0O0OO0O0O0 )
  common . addLink ( '[COLOR orangered]Disable History[/COLOR]' , ooO0oooOoO0 , 106 , iiiii , O0O0OO0O0O0 )
  common . addLink ( '###########################################' , ooO0oooOoO0 , 999 , iiiii , O0O0OO0O0O0 )
  if 16 - 16: iIiI1I11 % ooOoo0O - iIiI1I11 + oO0o0ooo
  Ii11I = open ( oOoOo00oOo , mode = 'r' ) ; OOO0OOO00oo = Ii11I . read ( ) ; Ii11I . close ( )
  OOO0OOO00oo = OOO0OOO00oo . replace ( '\n' , '' )
  O0 = re . compile ( '<item>(.+?)</item>' ) . findall ( OOO0OOO00oo )
  for iII in O0 :
   i1I1i = re . compile ( '<date>(.+?)</date>' ) . findall ( iII ) [ 0 ]
   time = re . compile ( '<time>(.+?)</time>' ) . findall ( iII ) [ 0 ]
   Ii = re . compile ( '<name>(.+?)</name>' ) . findall ( iII ) [ 0 ]
   I1I1IiI1 = re . compile ( '<link>(.+?)</link>' ) . findall ( iII ) [ 0 ]
   iii1i = re . compile ( '<site>(.+?)</site>' ) . findall ( iII ) [ 0 ]
   I11i1ii1 = re . compile ( '<icon>(.+?)</icon>' ) . findall ( iII ) [ 0 ]
   I1I1IiI1 = Ii + '|SPLIT|' + I1I1IiI1 + '|SPLIT|' + iii1i + '|SPLIT|' + I11i1ii1 + '|SPLIT|' + I1I1IiI1
   if 87 - 87: ii1I11II1ii1i - Oo00O0 + i111I1 . OoO0
   common . addLink ( '[COLOR pink]' + i1I1i + ' | ' + '[/COLOR][COLOR deeppink]' + time + '[/COLOR] - [COLOR orangered]' + iii1i + '[/COLOR][COLOR pink] - ' + Ii + '[/COLOR]' , I1I1IiI1 , 800 , I11i1ii1 , O0O0OO0O0O0 )
 else :
  common . addLink ( '[COLOR orangered]Enable History Monitoring[/COLOR]' , ooO0oooOoO0 , 106 , iiiii , O0O0OO0O0O0 )
  common . addLink ( '############################################' , ooO0oooOoO0 , 106 , iiiii , O0O0OO0O0O0 )
  common . addLink ( '[COLOR pink]History monitoring is currently disabled.[/COLOR]' , ooO0oooOoO0 , 106 , iiiii , O0O0OO0O0O0 )
  if 62 - 62: o00ooo0 * O0Oooo00 * IIIIII11i1I - i111I1 + i111I1
def iiI1I111 ( ) :
 if 24 - 24: oo
 common . addLink ( '[COLOR deeppink]Your Favourites[/COLOR]' , ooO0oooOoO0 , 999 , iiiii , O0O0OO0O0O0 )
 common . addLink ( '###########################################' , ooO0oooOoO0 , 999 , iiiii , O0O0OO0O0O0 )
 if 61 - 61: oo - ooOoo0O % oO0o0ooo % IiIiiI + o0o0OOO0o0
 Ii11I = open ( Ooo00O00O0O0O , mode = 'r' ) ; OOO0OOO00oo = Ii11I . read ( ) ; Ii11I . close ( )
 OOO0OOO00oo = OOO0OOO00oo . replace ( '\n' , '' )
 O0 = re . compile ( '<item>(.+?)</item>' ) . findall ( OOO0OOO00oo )
 for iII in O0 :
  Ii = re . compile ( '<name>(.+?)</name>' ) . findall ( iII ) [ 0 ]
  I1I1IiI1 = re . compile ( '<link>(.+?)</link>' ) . findall ( iII ) [ 0 ]
  iii1i = re . compile ( '<site>(.+?)</site>' ) . findall ( iII ) [ 0 ]
  I11i1ii1 = re . compile ( '<icon>(.+?)</icon>' ) . findall ( iII ) [ 0 ]
  I1I1IiI1 = Ii + '|SPLIT|' + I1I1IiI1 + '|SPLIT|' + iii1i + '|SPLIT|' + I11i1ii1 + '|SPLIT|' + I1I1IiI1
  common . addLink ( '[COLOR orangered]' + iii1i + '[/COLOR][COLOR pink] - ' + Ii + '[/COLOR]' , I1I1IiI1 , 103 , I11i1ii1 , O0O0OO0O0O0 )
  if 64 - 64: IIII * o00ooo0 . i111I1 + iIiI1I11
def IIi1i ( name , url , iconimage ) :
 if 87 - 87: IIIIII11i1I - o0o0OOO0o0 + Oo0O0OOOoo % OoO0 + i111I1 - ooOoo0O
 i1I = url
 oO000Oo000 , i111IiI1I , OoOO , ooOOO0 , url = url . split ( '|SPLIT|' )
 if 65 - 65: o00ooo0
 i1i = '\n<item>\n<name>' + oO000Oo000 + '</name>\n<link>' + i111IiI1I + '</link>\n<site>' + OoOO + '</site>\n<icon>' + ooOOO0 + '</icon>\n</item>\n'
 if 68 - 68: o0O0 % IiIiiI
 Iii111II = II11i . select ( "[COLOR orangered][B]Please select an option[/B][/COLOR]" , [ '[COLOR pink][B]Watch Video[/B][/COLOR]' , '[COLOR pink][B]Remove from Favourites[/B][/COLOR]' ] )
 if 88 - 88: Oo00O0 - oO0oOOO00oO + o0O0
 if Iii111II == 0 :
  IiI111111IIII ( name , i1I , iconimage )
 else :
  i1Ii = open ( Ooo00O00O0O0O ) . read ( )
  Ii11I = i1Ii . replace ( i1i , '\n' )
  ii111iI1iIi1 = open ( Ooo00O00O0O0O , mode = 'w' )
  ii111iI1iIi1 . write ( str ( Ii11I ) )
  ii111iI1iIi1 . close ( )
  xbmc . executebuiltin ( "Container.Refresh" )
  quit ( )
  if 78 - 78: iiIiIIi . o0O0 + iiIiIIi / ii1I11II1ii1i / iiIiIIi
def oO0O00OoOO0 ( name , url , iconimage ) :
 if 82 - 82: iIiI1I11 . Oo0O0OOOoo - Oo00O0 - Oo0O0OOOoo * iIiI1I11
 i1I = url
 oO000Oo000 , i111IiI1I , OoOO , ooOOO0 , url = url . split ( '|SPLIT|' )
 if 77 - 77: Oo00O0 * iiIiIIi
 Iii111II = II11i . select ( "[COLOR orangered][B]Please select an option[/B][/COLOR]" , [ '[COLOR pink][B]Watch Video[/B][/COLOR]' , '[COLOR pink][B]Delete Download[/B][/COLOR]' ] )
 if 95 - 95: i111I1 + i11iIiiIii
 if Iii111II == 0 :
  IiI111111IIII ( name , i1I , iconimage )
 else :
  os . remove ( url )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 6 - 6: oO0oOOO00oO / i11iIiiIii + OoO0 * IIII
def o00o0 ( ) :
 if 45 - 45: o00ooo0
 if os . path . isfile ( oOoOo00oOo ) :
  Iii111II = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]Would you like to clear all stored history?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[B][COLOR orangered]NO[/COLOR][/B]' )
  if Iii111II == 1 :
   os . remove ( oOoOo00oOo )
   Ii11I = open ( oOoOo00oOo , 'w' )
   Ii11I . write ( '#START OF FILE#' )
   Ii11I . close ( )
 xbmc . executebuiltin ( "Container.Refresh" )
 if 26 - 26: ii1I11II1ii1i - Oo00O0 - i111I1 / iiIiIIi . ooOoo0O % Oo00O0
def OO ( ) :
 if 25 - 25: iiIiIIi
 O0o0 = plugintools . get_setting ( "download_location" )
 oOo0oO = xbmc . translatePath ( O0o0 )
 common . addLink ( '[COLOR deeppink]Download Location: [/COLOR]' , ooO0oooOoO0 , 999 , iiiii , O0O0OO0O0O0 )
 common . addLink ( oOo0oO , ooO0oooOoO0 , 999 , iiiii , O0O0OO0O0O0 )
 common . addLink ( '[COLOR orangered]Change Download Location[/COLOR]' , ooO0oooOoO0 , 106 , iiiii , O0O0OO0O0O0 )
 common . addLink ( '###########################################' , ooO0oooOoO0 , 999 , iiiii , O0O0OO0O0O0 )
 if 51 - 51: oOoO - IIII + iIiI1I11 * oO0o0ooo . ii1I11II1ii1i + IIII
 OoO0o = [ '.mp4' ]
 if 78 - 78: IIII % o00ooo0 % oO0o0ooo
 for file in os . listdir ( oOo0oO ) :
  for ii in OoO0o :
   if file . endswith ( ii ) :
    I11i1ii1 = iiiii
    Ii11I = open ( OooO0OO , mode = 'r' ) ; OOO0OOO00oo = Ii11I . read ( ) ; Ii11I . close ( )
    OOO0OOO00oo = OOO0OOO00oo . replace ( '\n' , '' )
    O0 = re . compile ( '<item>(.+?)</item>' ) . findall ( OOO0OOO00oo )
    for iII in O0 :
     Ii = re . compile ( '<name>(.+?)</name>' ) . findall ( iII ) [ 0 ]
     I1Ii1iI1 = re . compile ( '<icon>(.+?)</icon>' ) . findall ( iII ) [ 0 ]
     if file in Ii :
      I11i1ii1 = I1Ii1iI1
    I1I1IiI1 = xbmc . translatePath ( os . path . join ( oOo0oO , file ) )
    if "http" in I11i1ii1 :
     oO0O0OO0O = file + '|SPLIT|' + I1I1IiI1 + '|SPLIT|Downloaded|SPLIT|' + I11i1ii1 + '|SPLIT|' + I1I1IiI1
    else :
     oO0O0OO0O = file + '|SPLIT|' + I1I1IiI1 + '|SPLIT|Downloaded|SPLIT|None|SPLIT|' + I1I1IiI1
    common . addLink ( '[COLOR pink]' + file + '[/COLOR]' , oO0O0OO0O , 107 , I11i1ii1 , O0O0OO0O0O0 )
    if 81 - 81: IIII . IIIIII11i1I % o00ooo0 / i111I1 - IIII
def Ii1I1i ( ) :
 if 99 - 99: IIII . OoO0 + oO0oOOO00oO % IIII . i11iIiiIii % o00ooo0
 O0o0 = plugintools . get_setting ( "download_location" )
 oOO00O = II11i . browse ( 3 , Oo0Ooo , 'files' , '' , False , False , Ooo0 )
 i1Ii = open ( oo00000o0 ) . read ( )
 Ii11I = i1Ii . replace ( O0o0 , oOO00O )
 ii111iI1iIi1 = open ( oo00000o0 , mode = 'w' )
 ii111iI1iIi1 . write ( str ( Ii11I ) )
 ii111iI1iIi1 . close ( )
 xbmc . executebuiltin ( "Container.Refresh" )
 if 77 - 77: oOoO - O0Oooo00 - ii1I11II1ii1i . ooOoo0O
def IiI1i ( name , url , iconimage ) :
 if 92 - 92: Oo0O0OOOoo . Oo0O0OOOoo + iiIiIIi
 oO000Oo000 , i111IiI1I , OoOO , ooOOO0 , url = url . split ( '|SPLIT|' )
 name = oO000Oo000
 IiIiI1111I1I = datetime . datetime . now ( ) . strftime ( "%d-%m-%Y" )
 i1ioOOoo00O00o = datetime . datetime . now ( ) . strftime ( "%H:%M" )
 i1i = '\n<item>\n<date>' + IiIiI1111I1I + '</date>\n<time>' + i1ioOOoo00O00o + '</time>\n<name>' + oO000Oo000 + '</name>\n<link>' + i111IiI1I + '</link>\n<site>' + OoOO + '</site>\n<icon>' + ooOOO0 + '</icon>\n</item>\n'
 oO000Oo000 = open ( oOoOo00oOo ) . read ( )
 i111IiI1I = oO000Oo000 . replace ( '#START OF FILE#' , '#START OF FILE#' + i1i )
 Ii11I = open ( oOoOo00oOo , mode = 'w' )
 Ii11I . write ( str ( i111IiI1I ) )
 Ii11I . close ( )
 if 98 - 98: o0O0 + Oo0O0OOOoo + IIII % oo
 if iconimage == "None" :
  iconimage = iiiii
 oooooo0O000o = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , oooooo0O000o , False )
 if 64 - 64: i111I1 . IIIIII11i1I - IiIiiI / oo
def IiI111111IIII ( name , url , iconimage ) :
 if 66 - 66: OoO0 - OoO0 - i11iIiiIii . o0o0OOO0o0 - o0O0
 oO000Oo000 , i111IiI1I , OoOO , ooOOO0 , url = url . split ( '|SPLIT|' )
 name = oO000Oo000
 IiIiI1111I1I = datetime . datetime . now ( ) . strftime ( "%d-%m-%Y" )
 i1ioOOoo00O00o = datetime . datetime . now ( ) . strftime ( "%H:%M" )
 i1i = '\n<item>\n<date>' + IiIiI1111I1I + '</date>\n<time>' + i1ioOOoo00O00o + '</time>\n<name>' + oO000Oo000 + '</name>\n<link>' + i111IiI1I + '</link>\n<site>' + OoOO + '</site>\n<icon>' + ooOOO0 + '</icon>\n</item>\n'
 oO000Oo000 = open ( oOoOo00oOo ) . read ( )
 i111IiI1I = oO000Oo000 . replace ( '#START OF FILE#' , '#START OF FILE#' + i1i )
 Ii11I = open ( oOoOo00oOo , mode = 'w' )
 Ii11I . write ( str ( i111IiI1I ) )
 Ii11I . close ( )
 if 77 - 77: ooOoo0O - iIiI1I11 - oO0oOOO00oO
 if iconimage == "None" :
  iconimage = iiiii
  if 49 - 49: iIiI1I11 % o00ooo0 . ooOoo0O + IIII / i111I1
 if "highwebmedia" in url :
  II11i . ok ( Oo0Ooo , '[COLOR pink]Chaturbate links are taken at the time of broadcasting. If this broadcast has ended the link will no longer play. [/COLOR]' )
 oooooo0O000o = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , oooooo0O000o , False )
 if 72 - 72: oO0oOOO00oO * oOoO . i111I1 - iIiI1I11 + O0Oooo00
def iIi1ii ( name , url , iconimage ) :
 if 58 - 58: ooOoo0O % IIIIII11i1I
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
   if 50 - 50: IiIiiI . IIIIII11i1I
 oooooo0O000o = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , oooooo0O000o , False )
 if 97 - 97: o00ooo0 + ooOoo0O
def i11 ( ) :
 if 89 - 89: IIIIII11i1I + iiIiIIi * ii1I11II1ii1i * oO0o0ooo
 ii11i1 = common . _get_keyboard ( heading = "Please Set Password" )
 if ( not ii11i1 ) :
  II11i . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 IIIii1II1II = ii11i1
 if 37 - 37: oo - o00ooo0 - IIIIII11i1I
 ii11i1 = common . _get_keyboard ( heading = "Please Confirm Your Password" )
 if ( not ii11i1 ) :
  II11i . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 o0o0O0O00oOOo = ii11i1
 if 14 - 14: ooOoo0O + IIII
 if not os . path . exists ( oO000OoOoo00o ) :
  if not os . path . exists ( I11i1i11i1I ) :
   os . makedirs ( I11i1i11i1I )
  open ( oO000OoOoo00o , 'w' )
  if 52 - 52: oo - oO0oOOO00oO
  if IIIii1II1II == o0o0O0O00oOOo :
   o0O0o0 = base64 . b64encode ( IIIii1II1II )
   Ii11I = open ( oO000OoOoo00o , 'w' )
   Ii11I . write ( '<password>' + str ( o0O0o0 ) + '</password>' )
   Ii11I . close ( )
   II11i . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   II11i . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
 else :
  os . remove ( oO000OoOoo00o )
  if 37 - 37: o0o0OOO0o0 * ii1I11II1ii1i % i11iIiiIii % oO0oOOO00oO + oO0o0ooo
  if IIIii1II1II == o0o0O0O00oOOo :
   o0O0o0 = base64 . b64encode ( IIIii1II1II )
   Ii11I = open ( oO000OoOoo00o , 'w' )
   Ii11I . write ( '<password>' + str ( o0O0o0 ) + '</password>' )
   Ii11I . close ( )
   II11i . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   II11i . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
   if 78 - 78: o0o0OOO0o0 % IIII / OoO0 - Oo00O0
def ooooo0O0000oo ( ) :
 if 21 - 21: IIIIII11i1I - i111I1
 try :
  os . remove ( oO000OoOoo00o )
  II11i . ok ( Oo0Ooo , 'Parental controls have been disabled.' )
  xbmc . executebuiltin ( "Container.Refresh" )
 except :
  II11i . ok ( Oo0Ooo , 'There was an error disabling the parental controls.' )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 18 - 18: oOoO + ii1I11II1ii1i % o0O0 - oo - o0o0OOO0o0 / O0Oooo00
def oo0oO ( ) :
 if 94 - 94: Oo00O0 / oOoO % OoO0 * OoO0 * iIiI1I11
 IIiIiI = 0
 if 94 - 94: IIII . O0Oooo00 - IIIIII11i1I % o00ooo0 - iiIiIIi
 try :
  common . open_url ( "http://www.google.com" )
 except :
  II11i . ok ( Oo0Ooo , '[COLOR orangered]Error: It appears you do not currently have an active internet connection. This will cause false positives in the test. Please try again with an active internet connection.[/COLOR]' )
  return
  if 72 - 72: oO0o0ooo
 i1 . create ( Oo0Ooo , "Checking for repository updates" , '' , 'Please Wait...' )
 i1 . update ( 0 )
 oO000Oo000 = open ( II11iiii1Ii ) . read ( )
 i111IiI1I = oO000Oo000 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 O0 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( i111IiI1I ) )
 for iII in O0 :
  i1 . update ( 25 )
  II11Ii1iI1iII = float ( iII ) + 0.01
  I1I1IiI1 = O0o0Oo + str ( II11Ii1iI1iII ) + '.zip'
  try :
   Oo0o00OO0000 = common . open_url ( I1I1IiI1 )
   if "Not Found" not in Oo0o00OO0000 :
    iIIi1i1 = 1
    i1 . update ( 75 )
    I1i = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    if not os . path . exists ( I1i ) :
     os . makedirs ( I1i )
    O00Oooo = os . path . join ( I1i , 'repoupdate.zip' )
    try : os . remove ( O00Oooo )
    except : pass
    i1 . update ( 100 )
    i1 . update ( 0 , "" , "Downloading Update Please Wait" , "" )
    downloader . download ( I1I1IiI1 , O00Oooo , i1 )
    i11I = xbmc . translatePath ( os . path . join ( 'special://' , 'home/addons' ) )
    i1 . update ( 0 , "" , "Extracting Update Please Wait" , "" )
    extract . all ( O00Oooo , i11I , i1 )
    try : os . remove ( O00Oooo )
    except : pass
    xbmc . executebuiltin ( "UpdateLocalAddons" )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    IIiIiI = 1
    II11i . ok ( Oo0Ooo , "ECHO XXX repository was updated to " + str ( II11Ii1iI1iII ) + ', you may need to restart the addon for changes to take effect' )
    time . sleep ( 2 )
  except : pass
  if 76 - 76: Oo0O0OOOoo * OoO0
 i1 . update ( 75 , "Checking for addon updates" )
 oO000Oo000 = open ( OooO0 ) . read ( )
 i111IiI1I = oO000Oo000 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 O0 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( i111IiI1I ) )
 for iII in O0 :
  II11Ii1iI1iII = float ( iII ) + 0.01
  I1I1IiI1 = OO0oOoo + str ( II11Ii1iI1iII ) + '.zip'
  try :
   Oo0o00OO0000 = common . open_url ( I1I1IiI1 )
   if "Not Found" not in Oo0o00OO0000 :
    iIIi1i1 = 1
    i1 . update ( 75 )
    I1i = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    if not os . path . exists ( I1i ) :
     os . makedirs ( I1i )
    O00Oooo = os . path . join ( I1i , 'xxx_o_dus_update.zip' )
    try : os . remove ( O00Oooo )
    except : pass
    i1 . update ( 100 )
    i1 . update ( 0 , "" , "Downloading Update Please Wait" , "" )
    downloader . download ( I1I1IiI1 , O00Oooo , i1 )
    i11I = xbmc . translatePath ( os . path . join ( 'special://' , 'home/addons' ) )
    i1 . update ( 0 , "" , "Extracting Update Please Wait" , "" )
    extract . all ( O00Oooo , i11I , i1 )
    try : os . remove ( O00Oooo )
    except : pass
    xbmc . executebuiltin ( "UpdateLocalAddons" )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    i1 . update ( 100 )
    i1 . close
    IIiIiI = 1
    II11i . ok ( Oo0Ooo , "XXX-O-DUS was updated to " + str ( II11Ii1iI1iII ) + ', you may need to restart the addon for changes to take effect' )
    time . sleep ( 2 )
  except : pass
  if 52 - 52: o0O0
 if i1 . iscanceled ( ) :
  i1 . close ( )
  if 19 - 19: i111I1
 return IIiIiI
 if 25 - 25: oO0o0ooo / oO0oOOO00oO
def IIooO ( url ) :
 if 51 - 51: i111I1 % IiIiiI . IIII / Oo00O0 / ii1I11II1ii1i . IIII
 Ii11I = open ( url , mode = 'r' ) ; OOO0OOO00oo = Ii11I . read ( ) ; Ii11I . close ( )
 common . TextBoxes ( "%s" % OOO0OOO00oo )
 if 42 - 42: IIIIII11i1I + O0Oooo00 - oO0o0ooo / Oo0O0OOOoo
 if url == II111iiii :
  return
  if 9 - 9: o00ooo0 % o00ooo0 - IIIIII11i1I
def OoO ( ) :
 if 12 - 12: o00ooo0 - IIIIII11i1I
 try :
  IIooO ( II111iiii )
  if 81 - 81: ooOoo0O - ooOoo0O . OoO0
  Iii111II = xbmcgui . Dialog ( ) . yesno ( "[COLOR orangered][B]RESET XXX-O-DUS?[/B][/COLOR]" , '[COLOR white]ARE YOU SURE YOU WANT TO RETURN XXX-O-DUS TO THE DEFAULT STATE AND LOSE ALL YOUR INFORMATION?[/COLOR]' , '' , yeslabel = '[COLOR green]YES[/COLOR]' , nolabel = '[COLOR orangered]NO[/COLOR]' )
  if Iii111II == 1 :
   O0o0 = plugintools . get_setting ( "download_location" )
   oOo0oO = xbmc . translatePath ( O0o0 )
   if 73 - 73: ii1I11II1ii1i % i11iIiiIii - i111I1
   OoO0o = [ '.mp4' ]
   if 7 - 7: o00ooo0 * i11iIiiIii * oO0o0ooo + oO0oOOO00oO % iiIiIIi - oO0oOOO00oO
   for file in os . listdir ( oOo0oO ) :
    for ii in OoO0o :
     if file . endswith ( ii ) :
      try :
       I1i = xbmc . translatePath ( os . path . join ( oOo0oO , file ) )
       os . remove ( I1i )
      except :
       II11i . ok ( Oo0Ooo , "[COLOR white]There was an error deleting " + file + "[/COLOR]" )
       pass
   try :
    shutil . rmtree ( Iiii )
   except :
    II11i . ok ( Oo0Ooo , "[COLOR white]There was an error deleting deleting the data directory.[/COLOR]" )
    pass
   II11i . ok ( Oo0Ooo , "[COLOR white]XXX-O-DUS has been reset to the factory state.[/COLOR]" , "[COLOR white]Press OK to continue.[/COLOR]" )
   xbmc . executebuiltin ( "Container.Refresh" )
 except :
  II11i . ok ( Oo0Ooo , "[COLOR white]Sorry, something went wrong.[/COLOR]" , "[COLOR white]Please report this issue to @EchoCoder on Twitter.[/COLOR]" )
  quit ( )
  if 39 - 39: oOoO * o0O0 % o0O0 - oo + IIIIII11i1I - ii1I11II1ii1i
def iiO0oOo00o ( ) :
 o0ooooO0o0O = [ ]
 iiIi11iI1iii = sys . argv [ 2 ]
 if len ( iiIi11iI1iii ) >= 2 :
  oo000 = sys . argv [ 2 ]
  o0000oO = oo000 . replace ( '?' , '' )
  if ( oo000 [ len ( oo000 ) - 1 ] == '/' ) :
   oo000 = oo000 [ 0 : len ( oo000 ) - 2 ]
  iI1i111I1Ii = o0000oO . split ( '&' )
  o0ooooO0o0O = { }
  for i1Oo00 in range ( len ( iI1i111I1Ii ) ) :
   i11i1ii1I = { }
   i11i1ii1I = iI1i111I1Ii [ i1Oo00 ] . split ( '=' )
   if ( len ( i11i1ii1I ) ) == 2 :
    o0ooooO0o0O [ i11i1ii1I [ 0 ] ] = i11i1ii1I [ 1 ]
    if 88 - 88: ii1I11II1ii1i % o0o0OOO0o0
 return o0ooooO0o0O
 if 48 - 48: oO0oOOO00oO / IiIiiI . Oo00O0 * ooOoo0O * IIII / O0Oooo00
oo000 = iiO0oOo00o ( ) ; OOOOoOOo0O0 = None ; I1I1IiI1 = None ; oOooo0 = None ; I11i1ii1 = None ; ooO = None
try : OOOOoOOo0O0 = urllib . unquote_plus ( oo000 [ "name" ] )
except : pass
try : I1I1IiI1 = urllib . unquote_plus ( oo000 [ "url" ] )
except : pass
try : oOooo0 = int ( oo000 [ "mode" ] )
except : pass
try : I11i1ii1 = urllib . unquote_plus ( oo000 [ "iconimage" ] )
except : pass
try : ooO = urllib . quote_plus ( oo000 [ "fanartimage" ] )
except : pass
if 84 - 84: o0O0 - OoO0 / oO0oOOO00oO
if oOooo0 == None or I1I1IiI1 == None or len ( I1I1IiI1 ) < 1 : Ooooo ( )
elif oOooo0 == 1 : menus . SEARCH ( )
elif oOooo0 == 2 : menus . VIDEOS ( )
elif oOooo0 == 3 : menus . LIVE ( )
elif oOooo0 == 4 : menus . PICTURES ( )
elif oOooo0 == 5 : menus . STORIES ( )
elif oOooo0 == 6 : menus . ALL ( )
elif oOooo0 == 10 : xhamster . MAIN_MENU ( )
elif oOooo0 == 11 : xhamster . GET_CONTENT ( I1I1IiI1 )
elif oOooo0 == 12 : xhamster . SEARCH ( )
elif oOooo0 == 13 : xhamster . PLAY_URL ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 20 : chaturbate . MAIN_MENU ( )
elif oOooo0 == 21 : chaturbate . GET_CONTENT ( I1I1IiI1 )
elif oOooo0 == 22 : chaturbate . SEARCH ( )
elif oOooo0 == 23 : chaturbate . PLAY_URL ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 30 : xnxx . MAIN_MENU ( )
elif oOooo0 == 31 : xnxx . GET_CONTENT ( I1I1IiI1 )
elif oOooo0 == 32 : xnxx . SEARCH ( )
elif oOooo0 == 33 : xnxx . PLAY_URL ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 34 : xnxx . PICTURE_MENU ( )
elif oOooo0 == 35 : xnxx . PICTURE_CONTENT ( I1I1IiI1 )
elif oOooo0 == 36 : xnxx . SCRAPE_GALLERY ( I1I1IiI1 )
elif oOooo0 == 37 : xnxx . DISPLAY_PICTURE ( I1I1IiI1 )
elif oOooo0 == 38 : xnxx . STORY_MENU ( )
elif oOooo0 == 39 : xnxx . LIST_STORIES ( I1I1IiI1 )
elif oOooo0 == 40 : xnxx . DISPLAY_STORY ( I1I1IiI1 )
elif oOooo0 == 41 : redtube . MAIN_MENU ( )
elif oOooo0 == 42 : redtube . GET_CONTENT ( I1I1IiI1 )
elif oOooo0 == 43 : redtube . SEARCH ( )
elif oOooo0 == 44 : redtube . PLAY_URL ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 50 : pornhd . MAIN_MENU ( )
elif oOooo0 == 51 : pornhd . GET_CONTENT ( I1I1IiI1 )
elif oOooo0 == 52 : pornhd . SEARCH ( )
elif oOooo0 == 53 : pornhd . PLAY_URL ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 60 : porncom . MAIN_MENU ( )
elif oOooo0 == 61 : porncom . GET_CONTENT ( I1I1IiI1 )
elif oOooo0 == 62 : porncom . SEARCH ( )
elif oOooo0 == 63 : porncom . PLAY_URL ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 70 : youporn . MAIN_MENU ( )
elif oOooo0 == 71 : youporn . GET_CONTENT ( I1I1IiI1 )
elif oOooo0 == 72 : youporn . SEARCH ( )
elif oOooo0 == 73 : youporn . PLAY_URL ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 80 : pornfun . MAIN_MENU ( )
elif oOooo0 == 81 : pornfun . GET_CONTENT ( I1I1IiI1 )
elif oOooo0 == 82 : pornfun . SEARCH ( )
elif oOooo0 == 83 : pornfun . PLAY_URL ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 90 : motherless . MAIN_MENU_PICTURES ( )
elif oOooo0 == 91 : motherless . GET_CONTENT_PICTURES ( I1I1IiI1 )
elif oOooo0 == 92 : motherless . DISPLAY_PICTURE ( I1I1IiI1 )
elif oOooo0 == 93 : motherless . MAIN_MENU ( )
elif oOooo0 == 94 : motherless . GET_CONTENT ( I1I1IiI1 )
elif oOooo0 == 95 : motherless . SEARCH ( )
elif oOooo0 == 96 : motherless . PLAY_URL ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 300 : watchxxxfree . MAIN_MENU ( )
elif oOooo0 == 301 : watchxxxfree . GET_CONTENT ( I1I1IiI1 )
elif oOooo0 == 302 : watchxxxfree . SEARCH ( )
elif oOooo0 == 303 : watchxxxfree . PLAY_URL ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 310 : perfectgirls . MAIN_MENU ( )
elif oOooo0 == 311 : perfectgirls . GET_CONTENT ( I1I1IiI1 )
elif oOooo0 == 312 : perfectgirls . SEARCH ( )
elif oOooo0 == 313 : perfectgirls . PLAY_URL ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 100 : oO0 ( ) ;
elif oOooo0 == 101 : OOOOoOoo0O0O0 ( )
elif oOooo0 == 102 : iiI1I111 ( )
elif oOooo0 == 103 : IIi1i ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 104 : o00o0 ( )
elif oOooo0 == 105 : OO ( )
elif oOooo0 == 106 : plugintools . open_settings_dialog ( ) ; xbmc . executebuiltin ( 'Container.Refresh' )
elif oOooo0 == 107 : oO0O00OoOO0 ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 200 : spankbang . MAIN_MENU ( )
elif oOooo0 == 201 : spankbang . SUB_MENU ( I1I1IiI1 )
elif oOooo0 == 202 : spankbang . GET_CONTENT ( I1I1IiI1 )
elif oOooo0 == 203 : spankbang . SEARCH ( )
elif oOooo0 == 204 : spankbang . PLAY_URL ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 210 : porn00 . MAIN_MENU ( )
elif oOooo0 == 211 : porn00 . GET_CONTENT ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 212 : porn00 . SEARCH ( )
elif oOooo0 == 213 : porn00 . PLAY_URL ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 220 : virtualpornstars . MAIN_MENU ( )
elif oOooo0 == 221 : virtualpornstars . GET_CONTENT ( I1I1IiI1 )
elif oOooo0 == 222 : virtualpornstars . SEARCH ( )
elif oOooo0 == 223 : virtualpornstars . PLAY_URL ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 230 : justpornotv . MAIN_MENU ( )
elif oOooo0 == 231 : justpornotv . GET_CONTENT ( I1I1IiI1 )
elif oOooo0 == 232 : justpornotv . SEARCH ( )
elif oOooo0 == 233 : justpornotv . PLAY_URL ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 240 : eporner . MAIN_MENU ( )
elif oOooo0 == 241 : eporner . GET_CONTENT ( I1I1IiI1 )
elif oOooo0 == 242 : eporner . SEARCH ( )
elif oOooo0 == 243 : eporner . PLAY_URL ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 800 : IiI111111IIII ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 900 : O0OOO ( )
elif oOooo0 == 901 : i11 ( )
elif oOooo0 == 902 : ooooo0O0000oo ( )
elif oOooo0 == 995 : common . GET_M3U_LIST ( I1I1IiI1 )
elif oOooo0 == 996 : iIi1ii ( OOOOoOOo0O0 , I1I1IiI1 , I11i1ii1 )
elif oOooo0 == 997 : OoO ( )
elif oOooo0 == 998 : IIooO ( I1I1IiI1 )
if 65 - 65: oO0o0ooo / ii1I11II1ii1i / ooOoo0O
if oOooo0 == None : xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) , cacheToDisc = False )
else : xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) , cacheToDisc = True )